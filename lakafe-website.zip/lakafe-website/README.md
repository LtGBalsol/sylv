# LAKAFÉ — Artisan Crafted

Website một trang cho quán matcha · cà phê · trà sữa **LAKAFÉ**
209/C3 Ấp Đức Long 3, Thống Nhất, Đồng Nai · 0922 248 509 · Google: "LAKAFÉ VN"

Điểm nhấn là hành trình điện ảnh **SPACE → EARTH → ASIA → SOUTHEAST ASIA → VIETNAM → ĐỒNG NAI → GIA KIỆM → LAKAFÉ**
(địa cầu 3D thật, zoom liên tục, tới đúng cửa quán), sau đó cuộn xuống để khám phá 49 món kèm nguyên liệu và tác dụng.

Không cần build: HTML + CSS + JavaScript thuần. Thư viện ngoài duy nhất là three.js (tải động từ CDN, có nguồn dự phòng). Không dùng GSAP.

---

## 1. Chạy thử

```bash
cd lakafe-website
python3 -m http.server 8080        # hoặc bất kỳ máy chủ tĩnh nào
# mở http://localhost:8080/
```

* Không mở bằng `file://` (một số tính năng của trình duyệt cần http/https).
* Hành trình tự chiếu **một lần mỗi phiên**. Muốn xem lại ngay: `http://localhost:8080/?intro=1`.
* Khi triển khai thật **bắt buộc dùng HTTPS** (Google Maps, sao chép địa chỉ, v.v.).

## 2. Cấu trúc

```
lakafe-website/
├─ index.html              trang duy nhất: hành trình + hero + câu chuyện + thực đơn + ghé thăm
├─ README.md
└─ assets/
   ├─ css/   base.css (biến, reset, bố cục) · intro.css (hành trình, HUD) · site.css (hero, câu chuyện)
   │         menu.css (thực đơn, hộp thoại món, ghé thăm, chân trang)
   ├─ img/   ảnh thực đơn (webp), xử lý từ ảnh chủ quán cung cấp
   └─ js/
      config.js        ◄── CHỈ CẦN SỬA FILE NÀY: địa điểm, API key, nhãn các chặng, nguồn ảnh
      core.js          tiện ích, lưu trữ, phát hiện thiết bị, hình học (ENU, Web Mercator), nội suy PCHIP, nạp tài nguyên
      location.js      xác định toạ độ KHÔNG phỏng đoán + công cụ xác nhận ?verify=1
      globe.js         địa cầu 3D (three.js): NASA Blue Marble, mây, ánh sáng mặt trời, khí quyển, sao
      tileplane.js     lớp ảnh vệ tinh theo quadtree uốn theo mặt cầu (hiện khi zoom sâu)
      satmap.js        bản đồ vệ tinh 2D: phương án dự phòng + bản đồ mục "Ghé thăm" + công cụ xác nhận
      google3d.js      Google Maps 3D (Map3DElement) — chỉ nạp khi có API key
      journey.js       đạo diễn hành trình: đường camera, chuyển cảnh, handoff, thích ứng hiệu năng
      intro-ui.js      HUD, thanh chặng, dấu vị trí, "YOU HAVE ARRIVED"
      main.js          khởi động, nút BỎ QUA / XEM LẠI, tham số URL
      menu-data.js     49 món (giá, nhóm, nguyên liệu)   ·   info-data.js  nguyên liệu/tác dụng + nguồn tham khảo
      site.js, motion.js   giao diện trang, hiệu ứng khi cuộn
```

## 3. Hành trình hoạt động thế nào (và không làm gì)

1. **Địa cầu**: three.js dựng Trái Đất bằng ảnh NASA (Blue Marble; đêm: Black Marble; mây), có ánh sáng mặt trời, khí quyển, sao, tự xoay chậm.
2. **Zoom liên tục**: một "đồng hồ" duy nhất và một đường camera duy nhất (nội suy PCHIP, vận tốc liên tục) đi qua 8 chặng.
   Không có cú nhảy cảnh, không màn hình trắng/đen.
3. **Ảnh chi tiết**: từ độ cao ~9.000 km trở xuống, địa cầu phủ thêm ảnh vệ tinh thật theo từng ô (tile) uốn theo mặt cầu.
   Đây là **một nguồn ảnh khác** (Esri), không phải ảnh NASA được phóng to — website không giả vờ rằng texture NASA zoom được tới cấp đường phố.
4. **Google Maps 3D (tuỳ chọn, cần API key)**: tới chặng `vietnam`, website khởi tạo sẵn `Map3DElement`, chờ sự kiện `gmp-steadychange`
   rồi mới crossfade từ địa cầu sang Google (đúng tư thế camera hiện tại) và dừng dựng three.js. Lỗi/không ổn định/quá hạn → tiếp tục bằng ảnh vệ tinh, không gián đoạn.
5. **Tới nơi**: dấu vị trí + vòng sáng, chữ **YOU HAVE ARRIVED AT LAKAFÉ**, quỹ đạo nhẹ quanh quán, rồi chuyển vào hero (cảnh vẫn sống ở nền). Cuộn xuống để khám phá thực đơn.
6. **Phương án dự phòng**: không có WebGL / three.js không tải được / thiết bị quá yếu → bản đồ vệ tinh 2D nghiêng bằng CSS (không dựng địa hình giả).
   Không có cả ảnh vệ tinh → bỏ qua hành trình, hiện website ngay.
7. **Không hy sinh việc cuộn**: nút **BỎ QUA** (và phím Esc) luôn có; hành trình khoá cuộn trong lúc chiếu và trả lại ngay khi xong/bỏ qua.
8. **Thiết bị yếu**: tự phân hạng (high / medium / low / none), tự giảm độ phân giải render nếu khung hình chậm. Chế độ **giảm chuyển động** (cài đặt hệ điều hành hoặc nút ở chân trang):
   không tự chiếu hành trình (chỉ chiếu khi bấm "Xem hành trình"), chạy chậm hơn, ít xoay.

---

## 4. TOẠ ĐỘ CỦA QUÁN — quan trọng nhất

**Website không bao giờ tự bịa toạ độ.** Hiện `latitude` / `longitude` trong `config.js` đang là `null` và `confirmed: false`, nên:

* hành trình bay tới **khu vực Thống Nhất, Đồng Nai** (toạ độ cấp xã lấy từ Wikipedia — chỉ để bay tới khu vực, **không ghim quán**);
* màn "tới nơi" ghi **YOU HAVE ARRIVED IN THỐNG NHẤT, ĐỒNG NAI**, không có ghim LAKAFÉ.

Khi có toạ độ đã xác nhận, hành trình dừng đúng cửa quán, có ghim và ghi **YOU HAVE ARRIVED AT LAKAFÉ**.

### Cách A — công cụ xác nhận `?verify=1` (khuyên dùng, không cần API key)

1. Trên máy tính, mở Google Maps → tìm **LAKAFÉ VN** → bấm vào ô của quán → **sao chép địa chỉ ở thanh địa chỉ**
   (dạng `https://www.google.com/maps/place/…/@10.9…,107.1…,17z/data=…!3d…!4d…`).
   * Link rút gọn `maps.app.goo.gl/…` **không chứa toạ độ** — phải mở nó ra trong trình duyệt, đợi bản đồ tải xong rồi mới sao chép địa chỉ.
   * Trên điện thoại: chạm giữ đúng cửa quán trên bản đồ để thả ghim → toạ độ hiện ở ô tìm kiếm phía trên → chạm giữ để sao chép.
2. Mở `https://TÊN-MIỀN/?verify=1` (khi chạy thử: `http://localhost:8080/?verify=1`) → dán vào ô *"Dán link Google Maps DẠNG DÀI…"*.
   Công cụ đọc được: link dài (`!3d…!4d…` hoặc `@lat,lng`), mã nhúng (`!2d…!3d…`), `?q=` / `ll=`, hoặc `vĩ độ, kinh độ`.
3. **Nhìn bằng mắt**: phóng sát trên ảnh vệ tinh, kiểm tra ghim nằm đúng cửa quán; bấm/kéo để chỉnh nếu lệch.
4. Bấm **Sao chép cấu hình cho config.js** → dán 3 dòng vào `LAKAFE_LOCATION` (thay cho `latitude: null, longitude: null, confirmed: false`):
   ```js
   latitude: 10.xxxxxx,
   longitude: 107.xxxxxx,
   confirmed: true,
   ```
   Chỉ đặt `confirmed: true` sau khi đã nhìn thấy ghim đúng cửa quán.

> "Lưu & xem thử trên trình duyệt này" chỉ lưu trong trình duyệt của riêng bạn (để xem thử hành trình). Khách khác **không** thấy cho tới khi bạn dán vào `config.js`.
> Nút "Xóa ghi đè" xoá bản lưu thử và bộ nhớ geocode.

### Cách B — để Google tự tìm ô "LAKAFÉ VN" (cần API key)

Khi có `googleMapsApiKey` (mục 5), website dùng **Places API (New)** tìm đúng ô *"LAKAFÉ VN, 209/C3 Ấp Đức Long 3…"* — ghim do chủ quán đặt trên Google chính xác hơn nhiều so với geocode một chuỗi địa chỉ ở vùng nông thôn. An toàn:
chỉ nhận ô có tên chứa "lakafe" **và** nằm trong `geocode.placesRadiusKm` (35 km) quanh khu vực Thống Nhất; nếu không có → quay về Geocoding API → OpenStreetMap Nominatim → khu vực (không ghim).
Có thể điền `googlePlaceId` (mã `ChIJ…` của ô) để bỏ bước tìm. Kết quả được nhớ 7 ngày trong trình duyệt.

Mỗi lượt tra cứu **tính phí** (mục 5) → dùng cách B **một lần** để lấy toạ độ (mở `?verify=1`, bấm *Sao chép cấu hình*, dán vào `config.js`), rồi đặt `geocode.enabled: false` khi chạy thật.

### Các trạng thái vị trí

| Trạng thái | Nguồn | Ghim | Màn "tới nơi" |
|---|---|---|---|
| `confirmed` | `config.js` + `confirmed: true` | có | YOU HAVE ARRIVED AT LAKAFÉ + địa chỉ |
| `provided` | `config.js`, `confirmed: false` | có (mục Ghé thăm ghi "tạm tính") | như trên |
| `override` | `?verify=1` lưu trong trình duyệt | có, chỉ máy bạn | như trên |
| `geocoded` | Google Places / Geocoder (ROOFTOP) / OSM mức số nhà | có (chưa xác nhận) | như trên |
| `approximate` | geocode chỉ ra mức khu vực | không | YOU HAVE ARRIVED IN … |
| `area` | khu vực Thống Nhất (Wikipedia) | không | YOU HAVE ARRIVED IN THỐNG NHẤT, ĐỒNG NAI |

Console của trình duyệt luôn ghi rõ trạng thái và nguồn hiện tại.

---

## 5. Google Maps Platform (API key)

Không có key vẫn chạy đầy đủ (dùng ảnh vệ tinh Esri). Có key thì có thêm: Google Photorealistic 3D ở chặng cuối, tìm ô LAKAFÉ VN, độ cao nền.

### Thiết lập an toàn

1. Google Cloud Console → tạo project → **bật thanh toán** (Google yêu cầu cho các API này).
2. Bật API: **Maps JavaScript API** (bắt buộc cho 3D), **Places API (New)** (tìm ô LAKAFÉ VN), **Geocoding API** (dự phòng), **Elevation API** (tuỳ chọn).
3. Tạo API key →
   * **Application restrictions: Websites (HTTP referrers)** — thêm `https://TÊN-MIỀN/*` (và `http://localhost:8080/*` cho máy dev, tốt nhất dùng key riêng cho dev);
   * **API restrictions: Restrict key** — chỉ chọn đúng các API ở bước 2.
4. Đặt **hạn mức theo ngày** cho từng API (Quotas) và **cảnh báo ngân sách** (Billing → Budgets & alerts).
5. Dán key vào `googleMapsApiKey` trong `config.js`.

> Website tĩnh thì key luôn nhìn thấy được trong trình duyệt — an toàn nằm ở bước 3–4 (giới hạn referrer + API + hạn mức), **không** ở việc giấu key.
> Đừng bao giờ dùng key không giới hạn, và đừng đẩy key lên kho mã công khai nếu chưa đặt giới hạn.

### Chi phí (tham khảo — Google cập nhật bảng giá ngày 03/11/2026; luôn kiểm tra lại trang giá chính thức)

Nguồn: <https://developers.google.com/maps/billing-and-pricing/pricing>

| Dịch vụ | Miễn phí / tháng | Sau đó (mỗi 1.000 lượt) |
|---|---|---|
| Maps JavaScript API — Dynamic Maps | 10.000 | 7 USD |
| 3D Maps ("Immersive Maps", gói Pro) — dòng gần nhất với `Map3DElement`* | 5.000 | 7 USD |
| Map Tiles API — Photorealistic 3D Tiles (website này không gọi trực tiếp) | 1.000 | 6 USD |
| Geocoding | 10.000 | 5 USD |
| Elevation | 5.000 | 5 USD |
| Places API (New) — Text Search Pro** | 5.000 | 32 USD |

\* Bảng giá không có dòng tên "Map3DElement"; hãy xác nhận SKU thực tế trong mục *Billing → Reports* sau vài ngày chạy.
\*\* SKU áp dụng phụ thuộc các trường dữ liệu yêu cầu (website yêu cầu `displayName`, `location`, `formattedAddress`); xem "Places API usage and billing".

Mỗi lượt xem hành trình có Google 3D ≈ 1 lượt tải bản đồ 3D (+ Geocoding/Places nếu chưa chốt toạ độ, + Elevation nếu chưa điền `groundAltitudeMeters`). Cách tiết kiệm:
chốt toạ độ vào `config.js` và đặt `geocode.enabled: false`; điền `groundAltitudeMeters` khi đã biết; chỉ chiếu hành trình mỗi phiên một lần (mặc định); hoặc tắt hẳn Google 3D bằng `google3d.enabled: false`.

### Tuân thủ điều khoản Google

* Mọi dữ liệu Google đi qua API chính thức; **không tải, không lưu trữ, không tự dựng lại** tile Google.
* Không che logo/attribution của Google: khi Google 3D hiển thị, các thanh đen điện ảnh thu lại, lớp tối góc mờ dần trước khi tới đáy, dòng ghi nguồn của website ẩn đi và nút hero được dời lên để chừa dải đáy.
* Nút "Chỉ đường" mở **Google Maps** bằng link của ô LAKAFÉ VN (`googleMapsUrl`).

## 6. Nhúng bản đồ Google thật vào mục "Ghé thăm" (không cần API key)

Google Maps → ô LAKAFÉ VN → **Chia sẻ → Nhúng bản đồ → Sao chép HTML**, dán nguyên đoạn `<iframe …>` (hoặc chỉ phần `src`) vào `googleEmbedUrl` trong `config.js`.
Website chỉ nhận địa chỉ bắt đầu bằng `https://www.google.com/maps/embed` (URL khác bị bỏ qua). Khi có, mục Ghé thăm hiện bản đồ Google thật, không phủ gì lên logo/attribution.
Mã nhúng này cũng dán được vào công cụ `?verify=1` để lấy toạ độ (đó là **tâm bản đồ lúc chia sẻ** — nhớ kiểm tra bằng mắt trước khi đặt `confirmed: true`).

---

## 7. Nguồn ảnh, giấy phép và ghi nguồn

| Thành phần | Nguồn | Ghi chú |
|---|---|---|
| Trái Đất ban ngày | NASA Blue Marble (GIBS / Visible Earth) | ghi nguồn NASA; **không dùng logo NASA**, không ngụ ý NASA bảo trợ |
| Ban đêm, mây | NASA Black Marble (GIBS), NASA Visible Earth | như trên |
| Ảnh vệ tinh chi tiết + bản đồ 2D dự phòng | Esri World Imagery | "Imagery © Esri, Maxar, Earthstar Geographics, and the GIS User Community" (hiển thị trong hành trình và bản đồ) |
| Google 3D | Google Maps Platform | logo + attribution do Google tự hiển thị, không bị che |
| three.js | MIT, tải từ jsDelivr/unpkg | `three@0.170.0` |
| Font | Be Vietnam Pro, Cormorant Garamond (SIL OFL) qua Google Fonts | có thể tự lưu trữ nếu muốn |
| Ảnh thực đơn | ảnh do chủ quán cung cấp | `assets/img/` |
| Nguyên liệu/tác dụng | FDA, NIH-NCCIH, NIH-ODS, UEA | liệt kê trong mục "Lưu ý & nguồn" của trang |

Texture NASA được thử lần lượt: `assets/tex/earth_day_4k.jpg` (tuỳ chọn — thả ảnh Blue Marble 4k vào đúng tên này nếu muốn Trái Đất nét hơn và không phụ thuộc mạng) → GIBS → Visible Earth → Esri.
Mỗi nguồn tải thành công mới được ghi vào dòng nguồn ảnh. Trước khi dùng một texture riêng, hãy đọc giấy phép ghi trên trang gốc của chính texture đó.

**⚠ Esri — cần xác nhận trước khi mở thương mại.** Ảnh chi tiết và bản đồ 2D dùng đường dẫn công khai của Esri World Imagery (`services.arcgisonline.com`).
Em không xác minh được điều khoản dùng thương mại của đường dẫn công khai này (các trang Esri tra cứu được không nêu rõ). Trước khi chạy thật hãy kiểm tra điều khoản Esri
(hoặc dùng tài khoản/khoá ArcGIS Location Platform), hoặc đổi nguồn bằng cách sửa `tiles.url` + `tiles.attribution` trong `config.js` (mẫu URL XYZ dùng `{z}` `{x}` `{y}` theo thứ tự tuỳ ý).
Ở vùng nông thôn, Esri có thể trả ô trống/độ phân giải thấp ở cấp zoom sát; `tiles.maxZoom` đang đặt 17 (chỉnh được). Có Google 3D thì phần zoom cuối do Google đảm nhận.

---

## 8. Tham số URL

| Tham số | Tác dụng |
|---|---|
| `?intro=1` / `?intro=0` | luôn chiếu / không chiếu hành trình |
| `?verify=1` | mở công cụ xác nhận toạ độ (không chiếu hành trình) |
| `?tier=high\|medium\|low\|none` | thử cấu hình thiết bị (`none` = không WebGL → bản đồ 2D) |
| `?calm=1` | bật chế độ giảm chuyển động và nhớ lại (tắt bằng nút ở chân trang) |

Trong `config.js`: `intro.autoplay` (`'session'` · `'always'` · `'never'`), `intro.speed` (>1 chậm hơn), `intro.maxLoadSeconds`, `intro.finalTilt`, `intro.orbitDegrees`,
`google3d.*` (chế độ `SATELLITE`/`HYBRID`, chặng chuyển sang Google, thời gian chờ), `stages` (nhãn từng chặng).

## 9. Chỉnh nội dung

* **Thực đơn**: `assets/js/menu-data.js` (tên, giá, nhóm, nguyên liệu; món "nổi bật" theo chấm đỏ trên menu).
* **Nguyên liệu & tác dụng khi cuộn**: `assets/js/info-data.js` (kèm danh sách nguồn). Đây là kiến thức chung về nguyên liệu, **không** phải công thức riêng của quán và không phải lời khuyên y tế.
* **Địa chỉ, điện thoại, giờ mở cửa, link Google Maps**: `LAKAFE_LOCATION` trong `config.js`.
* **Nhãn chặng**: `stages` trong `config.js` (đang có "GIA KIỆM" theo đề bài; địa chỉ của quán thuộc xã Thống Nhất — đổi nhãn nếu muốn).

## 10. Triển khai

* Đưa nguyên thư mục lên bất kỳ hosting tĩnh nào (Cloudflare Pages, Netlify, Vercel, GitHub Pages, nginx…) qua **HTTPS**.
* Khi có tên miền chính thức: bỏ chú thích 3 thẻ trong `<head>` của `index.html` (`og:url`, `canonical`, `og:image` — `og:image` **phải là URL tuyệt đối**) để Facebook/Zalo hiện ảnh xem trước; thêm tên miền vào referrer của API key.
* Nên bật nén (gzip/brotli) và cache dài cho `assets/` (tệp tĩnh).

## 11. Đã kiểm thử gì — và chưa kiểm thử được gì

**Đã kiểm thử** (Chromium thật, không GPU): bố cục máy tính/tablet/điện thoại; thực đơn, tìm kiếm, hộp thoại; bàn phím (Tab, Esc, giữ Tab trong hộp thoại, khoá phần trang phía sau khi đang chiếu); trợ năng (tiêu đề, alt, tên nút, tương phản);
toàn bộ hành trình bằng bản đồ 2D dự phòng **và** bằng chính mã địa cầu (`globe.js`, `tileplane.js`, `journey.js`) chạy trên bộ dựng WebGL2 thử nghiệm — không lỗi, ghim chiếu đúng giữa màn hình, tới cấp tile z17 khi dừng; BỎ QUA / XEM LẠI / Esc / giảm chuyển động / `?verify=1`;
logic xác định vị trí (Places, Geocoder, Place ID, bộ nhớ đệm, đọc link dài/mã nhúng) bằng đối tượng giả lập.

**Chưa kiểm thử được trong môi trường này — cần bạn thử trên thiết bị thật:**
1. three.js thật (em chạy bằng bộ dựng thử nghiệm thay thế, nên chi tiết ánh sáng/màu có thể khác đôi chút).
2. Chuyển cảnh sang Google Maps 3D (cần API key + mạng).
3. Tải texture NASA thật và ảnh Esri thật (môi trường thử chặn mạng ngoài; ảnh dùng để thử là ảnh giả).
4. Font thật (Be Vietnam Pro, Cormorant Garamond).
5. Hiệu năng GPU thật trên iPhone/Android (môi trường thử dựng bằng phần mềm ~10 khung/giây). Đã có tự điều chỉnh chất lượng, nhưng cần thử máy thật.
6. Tốc độ tải tile qua mạng thật.

## 12. Cần chủ quán xác nhận

1. **Toạ độ chính xác của quán** (mục 4) — chưa có thì website chỉ bay tới khu vực, không ghim.
2. **Giờ mở cửa**: menu ghi 08:00–17:00 (T2–T7), 07:00–16:00 (CN), nhưng Google Maps ghi "đóng cửa lúc 22:00".
3. Chấm đỏ trên menu đang được hiểu là "nổi bật" — đúng không?
4. Giá món **Bơ già dừa non** không thấy trên menu.
5. Hai cột "Đài / Nhật" trên menu matcha đang được hiểu là hai loại bột matcha.
6. Nhãn chặng "GIA KIỆM" so với địa chỉ "Thống Nhất" (mục 9).
7. Điều khoản Esri (mục 7) và có cấp **API key Google** hay không (mục 5).
