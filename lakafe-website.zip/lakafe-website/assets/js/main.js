/* ============================================================================
 * LAKAFÉ — Khởi động: quyết định có chiếu hành trình không, nối nút BỎ QUA / XEM LẠI, ?verify=1
 * Tham số URL: ?intro=0 (không chiếu) · ?intro=1 (luôn chiếu) · ?verify=1 (công cụ xác nhận vị trí)
 *              ?tier=high|medium|low|none (thử cấu hình thiết bị) · ?calm=1 (chế độ giảm chuyển động)
 * ========================================================================== */
(function (w) {
  'use strict';
  const L = w.LAKAFE, CFG = w.LAKAFE_CONFIG, u = L.util, $ = u.$, $$ = u.$$;
  w.LAKAFE_BOOTED = true;
  const root = document.documentElement, body = document.body;

  /* Hệ điều hành báo "giảm chuyển động" hoặc người dùng tự bật chế độ này: không tự chiếu cảnh zoom dài, chỉ chiếu khi họ bấm "Xem hành trình" */
  const wantsCalm = () => !!((w.matchMedia && w.matchMedia('(prefers-reduced-motion: reduce)').matches) || L.store.local.get('calm', false));

  function wantIntro() {
    const q = u.qs('intro'); if (q === '0') return false; if (q === '1') return true;
    const m = CFG.intro.autoplay; if (m === 'never') return false; if (m === 'always') return true;
    if (wantsCalm()) return false;
    return !L.store.session.get('seen', false);
  }

  function noIntro() {                                    // website hiện ngay, hero dùng ảnh tĩnh
    root.classList.remove('intro-pending'); body.classList.remove('intro-active'); body.classList.add('intro-done', 'intro-skipped');
    if (!L.store.session.get('seen', false)) {            // chưa từng xem: nút ghi "Xem hành trình" thay vì "Xem lại"
      $$('[data-replay]').forEach((b) => b.childNodes.forEach((n) => { if (n.nodeType === 3 && /Xem lại/.test(n.nodeValue)) n.nodeValue = n.nodeValue.replace('Xem lại', 'Xem'); }));
    }
  }

  function wireIntro() {
    const intro = $('#intro'); if (!intro) return;
    const skip = () => {
      const st = L.journey.status; if (st !== 'loading' && st !== 'running') return;
      intro.classList.add('is-leaving');                  // mờ dần rồi mới tắt, không giật
      setTimeout(() => {
        const s2 = L.journey.status;
        if (s2 === 'loading' || s2 === 'running') L.journey.skip();
        intro.classList.remove('is-leaving');
      }, 460);
    };
    $$('.hud-skip', intro).forEach((b) => b.addEventListener('click', skip));
    w.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !$('#item-dialog[open]')) skip(); });
    $$('[data-replay]').forEach((b) => b.addEventListener('click', () => {
      if (body.classList.contains('nav-open')) body.classList.remove('nav-open');
      L.journey.replay().catch((e) => { console.error('[LAKAFE] replay:', e); try { L.journey.finish(false, 'error'); } catch (x) { /* ok */ } });
    }));
  }

  function runJourney() {
    try { if ('scrollRestoration' in history) history.scrollRestoration = 'manual'; } catch (e) { /* ok */ }
    w.scrollTo(0, 0);
    let p; try { p = L.journey.start(); } catch (e) { p = Promise.reject(e); }
    root.classList.remove('intro-pending');               // intro đã tự hiện (J.start gỡ .is-gone đồng bộ)
    Promise.resolve(p).catch((e) => { console.error('[LAKAFE] hành trình lỗi → hiển thị website:', e); try { L.journey.finish(false, 'error'); } catch (x) { noIntro(); } });
  }

  function boot() {
    if (u.qs('calm') === '1') L.store.local.set('calm', true);
    L.introUI.init();
    L.site.init(); L.motion.reveal(); L.motion.start();
    wireIntro();
    if (u.qs('verify') === '1') { noIntro(); L.verify.open(); return; }
    if (wantIntro()) runJourney(); else noIntro();
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})(window);
