/* ============================================================================
 * LAKAFÉ — CORE: tiện ích, hình học địa lý, nội suy, tải tài nguyên, nhận diện thiết bị
 * ========================================================================== */
(function (w) {
  'use strict';
  const L = (w.LAKAFE = w.LAKAFE || {});
  const D2R = Math.PI / 180, R2D = 180 / Math.PI;

  /* ---------- tiện ích cơ bản ---------- */
  const u = (L.util = {
    clamp: (v, a, b) => Math.min(b, Math.max(a, v)),
    lerp: (a, b, t) => a + (b - a) * t,
    sstep(a, b, x) { const t = u.clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); },
    easeInOut: (t) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2),
    easeOut: (t) => 1 - Math.pow(1 - t, 3),
    mod: (a, n) => ((a % n) + n) % n,
    rad: D2R, deg: R2D,
    wait: (ms) => new Promise((r) => setTimeout(r, ms)),
    withTimeout(p, ms, label) {
      let id;
      const t = new Promise((_, rej) => { id = setTimeout(() => rej(new Error((label || 'timeout') + ' sau ' + ms + 'ms')), ms); });
      return Promise.race([p, t]).finally(() => clearTimeout(id));
    },
    qs: (k) => { try { return new URLSearchParams(location.search).get(k); } catch (e) { return null; } },
    isoDaysAgo: (ts) => (Date.now() - ts) / 864e5,
    $: (s, r) => (r || document).querySelector(s),
    $$: (s, r) => Array.from((r || document).querySelectorAll(s))
  });

  /* ---------- lưu trữ an toàn (có thể ném lỗi ở chế độ riêng tư) ---------- */
  const mk = (kind) => ({
    get(k, d) { try { const v = w[kind].getItem('lakafe:' + k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } },
    set(k, v) { try { w[kind].setItem('lakafe:' + k, JSON.stringify(v)); return true; } catch (e) { return false; } },
    del(k) { try { w[kind].removeItem('lakafe:' + k); } catch (e) { /* bỏ qua */ } }
  });
  L.store = { local: mk('localStorage'), session: mk('sessionStorage') };

  /* ---------- bus sự kiện nhỏ ---------- */
  const handlers = {};
  L.bus = {
    on(e, f) { (handlers[e] = handlers[e] || []).push(f); return () => L.bus.off(e, f); },
    off(e, f) { handlers[e] = (handlers[e] || []).filter((x) => x !== f); },
    emit(e, d) { (handlers[e] || []).slice().forEach((f) => { try { f(d); } catch (err) { console.error('[LAKAFE bus]', e, err); } }); }
  };

  /* ---------- ghi nguồn / attribution ---------- */
  const credits = new Map();
  L.credits = {
    add(key, text) { credits.set(key, text); L.bus.emit('credits', L.credits.list()); },
    list() { return Array.from(credits.values()); }
  };

  /* ---------- hình học địa lý ----------
   * Hệ vector "ecef": +Y = cực Bắc, +X = (0°N, 0°E), −Z = (0°N, 90°E).
   * ENU địa phương tại một điểm: x = Đông, y = Bắc, z = Lên (đơn vị km). */
  const R_KM = 6371.0088, C_KM = 40075.016686;
  const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
  const geo = (L.geo = {
    R: R_KM, C: C_KM, dot,
    ecef(lat, lng) { const p = lat * D2R, l = lng * D2R, c = Math.cos(p); return [c * Math.cos(l), Math.sin(p), -c * Math.sin(l)]; },
    basis(lat, lng) {
      const p = lat * D2R, l = lng * D2R, sp = Math.sin(p), cp = Math.cos(p), sl = Math.sin(l), cl = Math.cos(l);
      return { E: [-sl, 0, -cl], N: [-sp * cl, cp, sp * sl], U: [cp * cl, sp, -cp * sl] };
    },
    toEnu(v, b) { return [dot(v, b.E), dot(v, b.N), dot(v, b.U)]; },
    mercFrac(lat, lng) {
      const s = Math.sin(u.clamp(lat, -85.0511, 85.0511) * D2R);
      return { x: (lng + 180) / 360, y: 0.5 - Math.log((1 + s) / (1 - s)) / (4 * Math.PI) };
    },
    fracToLat(y) { const n = Math.PI - 2 * Math.PI * y; return R2D * Math.atan(0.5 * (Math.exp(n) - Math.exp(-n))); },
    fracToLng: (x) => x * 360 - 180,
    tileUrl: (tpl, z, x, y) => tpl.replace('{z}', z).replace('{x}', x).replace('{y}', y),
    /* zoom Web-Mercator (số thực) tương ứng một khoảng cách camera */
    zoomFromRange(rangeKm, lat, viewH, fovDeg) {
      const mpp = (2 * rangeKm * 1000 * Math.tan((fovDeg * D2R) / 2)) / viewH;
      return Math.log2((C_KM * 1000 * Math.cos(lat * D2R)) / (256 * mpp));
    },
    /* Khoảng cách đại cầu (km) */
    distKm(a, b) {
      const p1 = a.lat * D2R, p2 = b.lat * D2R, dl = (b.lng - a.lng) * D2R;
      const h = Math.sin((p2 - p1) / 2) ** 2 + Math.cos(p1) * Math.cos(p2) * Math.sin(dl / 2) ** 2;
      return 2 * R_KM * Math.asin(Math.min(1, Math.sqrt(h)));
    },
    /* Tư thế camera trong ENU (gốc = điểm mục tiêu trên mặt đất).
     * s: {range(km), tilt(° từ thẳng đứng), heading(° theo kim đồng hồ từ Bắc), look(0..1 → hướng vào tâm Trái Đất)} */
    cameraPose(s) {
      const t = s.tilt * D2R, h = s.heading * D2R;
      const hx = Math.sin(h), hy = Math.cos(h), st = Math.sin(t), ct = Math.cos(t);
      return {
        pos: [-st * hx * s.range, -st * hy * s.range, ct * s.range],
        up: [ct * hx, ct * hy, st],
        look: [0, 0, -R_KM * (s.look || 0)]
      };
    }
  });

  /* ---------- nội suy đơn điệu bậc ba (Fritsch–Carlson / PCHIP) ----------
   * Không vọt quá giá trị nút, vận tốc liên tục → camera trượt mượt qua các chặng. */
  L.pchip = function (ts, ys) {
    const n = ts.length, h = [], d = [], m = new Array(n);
    for (let i = 0; i < n - 1; i++) { h[i] = ts[i + 1] - ts[i]; d[i] = (ys[i + 1] - ys[i]) / h[i]; }
    m[0] = d[0]; m[n - 1] = d[n - 2];
    for (let i = 1; i < n - 1; i++) {
      if (d[i - 1] * d[i] <= 0) m[i] = 0;
      else { const w1 = 2 * h[i] + h[i - 1], w2 = h[i] + 2 * h[i - 1]; m[i] = (w1 + w2) / (w1 / d[i - 1] + w2 / d[i]); }
    }
    return function (t) {
      if (t <= ts[0]) return ys[0];
      if (t >= ts[n - 1]) return ys[n - 1];
      let i = 0; while (t > ts[i + 1]) i++;
      const s = (t - ts[i]) / h[i], s2 = s * s, s3 = s2 * s;
      return (2 * s3 - 3 * s2 + 1) * ys[i] + (s3 - 2 * s2 + s) * h[i] * m[i] + (-2 * s3 + 3 * s2) * ys[i + 1] + (s3 - s2) * h[i] * m[i + 1];
    };
  };

  /* ---------- tải tài nguyên ---------- */
  L.load = {
    script(urls, opt) {
      urls = [].concat(urls); const timeout = (opt && opt.timeout) || 8000;
      return urls.reduce((chain, url) => chain.catch(() => new Promise((res, rej) => {
        const s = document.createElement('script'); let done = false;
        const fail = (why) => { if (done) return; done = true; s.remove(); rej(new Error(why + ': ' + url)); };
        s.src = url; s.async = true; s.crossOrigin = 'anonymous';
        s.onload = () => { if (!done) { done = true; res(url); } };
        s.onerror = () => fail('Không tải được script');
        setTimeout(() => fail('Quá thời gian tải script'), timeout);
        document.head.appendChild(s);
      })), Promise.reject(new Error('start')));
    },
    module(urls, opt) {
      urls = [].concat(urls); const timeout = (opt && opt.timeout) || 12000;
      return urls.reduce((chain, url) => chain.catch(() => u.withTimeout(import(/* @vite-ignore */ url), timeout, 'module ' + url)), Promise.reject(new Error('start')));
    },
    image(url, opt) {
      const timeout = (opt && opt.timeout) || 15000;
      return u.withTimeout(new Promise((res, rej) => {
        const im = new Image(); im.crossOrigin = 'anonymous'; im.decoding = 'async';
        im.onload = () => res(im); im.onerror = () => rej(new Error('Ảnh lỗi: ' + url)); im.src = url;
      }), timeout, 'image');
    }
  };

  /* ---------- nhận diện thiết bị → mức chất lượng ---------- */
  const PROFILES = {
    high:   { dpr: 2,   sphere: [160, 80], stars: 7000, texW: 4096, clouds: true,  conc: 8, bias: 0,    google: true,  hud: true },
    medium: { dpr: 1.6, sphere: [96, 48],  stars: 3500, texW: 2048, clouds: true,  conc: 6, bias: -0.5, google: true,  hud: true },
    low:    { dpr: 1,   sphere: [64, 32],  stars: 1500, texW: 1024, clouds: false, conc: 4, bias: -1,   google: false, hud: true },
    none:   { dpr: 1,   sphere: [32, 16],  stars: 0,    texW: 1024, clouds: false, conc: 4, bias: -1,   google: false, hud: true }
  };
  L.device = {
    info: null,
    detect() {
      if (L.device.info) return L.device.info;
      const nav = navigator, conn = nav.connection || {};
      const mem = nav.deviceMemory || 4, cores = nav.hardwareConcurrency || 4;
      const coarse = !!(w.matchMedia && matchMedia('(pointer:coarse)').matches);
      const small = Math.min(screen.width, screen.height) < 700;
      const saveData = !!conn.saveData || /(^|-)2g$/.test(conn.effectiveType || '');
      const reduceMotion = !!(w.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches);
      let webgl = 0, renderer = '', maxTex = 0;
      try {
        const c = document.createElement('canvas');
        const gl = c.getContext('webgl2') || c.getContext('webgl');
        if (gl) {
          webgl = typeof WebGL2RenderingContext !== 'undefined' && gl instanceof WebGL2RenderingContext ? 2 : 1;
          maxTex = gl.getParameter(gl.MAX_TEXTURE_SIZE);
          const ext = gl.getExtension('WEBGL_debug_renderer_info');
          renderer = ext ? String(gl.getParameter(ext.UNMASKED_RENDERER_WEBGL)) : '';
          const lose = gl.getExtension('WEBGL_lose_context'); if (lose) lose.loseContext();
        }
      } catch (e) { /* không có WebGL */ }
      const software = /swiftshader|llvmpipe|software|basic render/i.test(renderer);
      let tier = 'high';
      if (!webgl || maxTex < 2048 || software) tier = 'none';
      else if (saveData || mem <= 2 || cores <= 2) tier = 'low';
      else if (coarse || small || mem <= 4 || cores <= 4) tier = 'medium';
      const force = u.qs('tier');
      if (force && PROFILES[force]) tier = force;
      const p = Object.assign({}, PROFILES[tier]);
      p.dpr = Math.min(w.devicePixelRatio || 1, p.dpr);
      L.device.info = { tier, profile: p, webgl, renderer, maxTex, coarse, small, saveData, reduceMotion, mem, cores };
      return L.device.info;
    }
  };

  /* ---------- DOM nhỏ ---------- */
  L.el = function (tag, cls, html) { const e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; };
})(window);
