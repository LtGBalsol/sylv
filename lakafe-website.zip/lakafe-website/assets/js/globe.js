/* ============================================================================
 * LAKAFÉ — Địa cầu 3D (Three.js): texture NASA Blue Marble, ánh sáng Mặt Trời + hoàng hôn,
 * đèn đêm, mây, khí quyển, bầu trời sao, và lớp ảnh vệ tinh chi tiết (TilePlane).
 * Mọi vật thể dùng depthTest=false + renderOrder; mặt cầu lồi nên chỉ cần cull mặt sau.
 * Hệ tọa độ cảnh: ENU (km) gốc tại điểm mục tiêu; tâm Trái Đất ở (0,0,-R).
 * ========================================================================== */
(function (w) {
  'use strict';
  const L = w.LAKAFE, u = L.util, geo = L.geo, CFG = w.LAKAFE_CONFIG, R = geo.R;

  const SH = (L.GLOBE_SHADERS = {
    earth: {
      vs: 'varying vec2 vUv; varying vec3 vObj;\nvoid main(){ vUv = uv; vObj = position; gl_Position = projectionMatrix * viewMatrix * modelMatrix * vec4(position, 1.0); }',
      fs: [
        'precision highp float;',
        'uniform sampler2D uDay, uNight; uniform vec3 uSun, uCamObj; uniform float uHasNight;',
        'varying vec2 vUv; varying vec3 vObj;',
        'void main(){',
        '  vec3 n = normalize(vObj); vec3 v = normalize(uCamObj - vObj);',
        '  float ndl = dot(n, uSun); vec3 day = texture2D(uDay, vUv).rgb;',
        '  float lit = smoothstep(-0.10, 0.22, ndl);',
        '  vec3 col = day * (0.035 + 1.05 * pow(clamp(ndl, 0.0, 1.0), 0.82));',
        '  float water = clamp((day.b - max(day.r, day.g * 0.8)) * 3.2, 0.0, 1.0);',
        '  vec3 h = normalize(uSun + v);',
        '  col += vec3(1.0, 0.93, 0.78) * pow(max(dot(n, h), 0.0), 70.0) * water * lit * 0.55;',
        '  float tw = exp(-pow(ndl * 5.0, 2.0));',
        '  col += vec3(0.95, 0.42, 0.18) * tw * 0.16 * (0.4 + 0.6 * day.g);',
        '  vec3 nl = texture2D(uNight, vUv).rgb;',
        '  col += uHasNight * nl * (1.0 - lit) * vec3(1.35, 1.0, 0.62) * 1.25;',
        '  float f = pow(1.0 - max(dot(n, v), 0.0), 3.2);',
        '  col += vec3(0.20, 0.45, 0.95) * f * (0.12 + 0.9 * lit) * 0.85;',
        '  gl_FragColor = vec4(col, 1.0); }'
      ].join('\n')
    },
    clouds: {
      vs: 'varying vec2 vUv; varying vec3 vObj;\nvoid main(){ vUv = uv; vObj = position; gl_Position = projectionMatrix * viewMatrix * modelMatrix * vec4(position, 1.0); }',
      fs: [
        'precision highp float;',
        'uniform sampler2D uClouds; uniform float uHas, uTime, uFade, uRot; uniform vec3 uSun;',
        'varying vec2 vUv; varying vec3 vObj;',
        'float hash(vec3 p){ p = fract(p * 0.3183099 + vec3(0.1, 0.2, 0.3)); p *= 17.0; return fract(p.x * p.y * p.z * (p.x + p.y + p.z)); }',
        'float vnoise(vec3 x){ vec3 i = floor(x), f = fract(x); f = f * f * (3.0 - 2.0 * f);',
        '  return mix(mix(mix(hash(i), hash(i + vec3(1,0,0)), f.x), mix(hash(i + vec3(0,1,0)), hash(i + vec3(1,1,0)), f.x), f.y),',
        '             mix(mix(hash(i + vec3(0,0,1)), hash(i + vec3(1,0,1)), f.x), mix(hash(i + vec3(0,1,1)), hash(i + vec3(1,1,1)), f.x), f.y), f.z); }',
        'float fbm(vec3 p){ float a = 0.5, s = 0.0; for (int i = 0; i < 5; i++){ s += a * vnoise(p); p *= 2.03; a *= 0.5; } return s; }',
        'void main(){',
        '  vec3 n = normalize(vObj); float c;',
        '  if (uHas > 0.5) { c = smoothstep(0.28, 0.95, texture2D(uClouds, vec2(vUv.x + uRot, vUv.y)).r); }',
        '  else { float cs = cos(uRot * 6.2831853), sn = sin(uRot * 6.2831853);',
        '    vec3 q = vec3(cs * n.x + sn * n.z, n.y, -sn * n.x + cs * n.z) * 3.2;',
        '    c = smoothstep(0.50, 0.78, fbm(q + vec3(0.0, uTime * 0.01, 0.0))); }',
        '  float ndl = dot(n, uSun); float lit = smoothstep(-0.12, 0.25, ndl);',
        '  vec3 col = vec3(1.0) * (0.06 + clamp(ndl, 0.0, 1.0)) + vec3(0.9, 0.5, 0.3) * exp(-pow(ndl * 5.0, 2.0)) * 0.08;',
        '  gl_FragColor = vec4(col, c * 0.88 * uFade * (0.15 + 0.85 * lit)); }'
      ].join('\n')
    },
    atmo: {
      vs: 'varying vec3 vWorld;\nvoid main(){ vec4 wp = modelMatrix * vec4(position, 1.0); vWorld = wp.xyz; gl_Position = projectionMatrix * viewMatrix * wp; }',
      fs: [
        'precision highp float;',
        'uniform vec3 uCenter, uSunW; uniform float uFade;',
        'varying vec3 vWorld;',
        'const float R = 6371.0088;',
        'void main(){',
        '  vec3 ro = cameraPosition; vec3 rd = normalize(vWorld - ro);',
        '  float tc = dot(uCenter - ro, rd); vec3 cp = ro + rd * max(tc, 0.0);',
        '  vec3 nrm = normalize(cp - uCenter); float b = length(cp - uCenter) / R; float g;',
        '  if (b < 1.0) { g = pow(smoothstep(0.80, 1.0, b), 2.6) * 0.95; }',
        '  else { float h = (b - 1.0) / 0.14; g = pow(clamp(1.0 - h, 0.0, 1.0), 3.2); }',
        '  float ndl = dot(nrm, uSunW); float lit = smoothstep(-0.30, 0.45, ndl);',
        '  float tw = exp(-pow((ndl - 0.02) * 3.2, 2.0));',
        '  vec3 col = mix(vec3(0.22, 0.47, 1.0), vec3(1.0, 0.52, 0.26), tw * 0.55) * (0.25 + 1.15 * lit);',
        '  gl_FragColor = vec4(col, g * uFade); }'
      ].join('\n')
    },
    stars: {
      vs: 'attribute float aSize; attribute vec3 aColor; attribute float aPh; uniform float uPR, uTime; varying vec3 vC; varying float vA;\n' +
        'void main(){ vC = aColor; float tw = 0.75 + 0.25 * sin(uTime * (0.6 + aPh * 1.4) + aPh * 40.0); vA = tw;\n' +
        '  gl_PointSize = aSize * uPR * (0.85 + 0.3 * tw); gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }',
      fs: 'precision highp float; varying vec3 vC; varying float vA;\nvoid main(){ float r = length(gl_PointCoord - 0.5); float a = smoothstep(0.5, 0.0, r); a *= a; gl_FragColor = vec4(vC * vA, a); }'
    }
  });

  /* mặt cầu tự dựng: vertex theo đúng hệ ecef của LAKAFE.geo, uv phẳng kiểu equirectangular */
  function buildSphere(THREE, radius, ws, hs) {
    const nv = (ws + 1) * (hs + 1), pos = new Float32Array(nv * 3), uv = new Float32Array(nv * 2); let k = 0, t = 0;
    for (let j = 0; j <= hs; j++) {
      const lat = 90 - (180 * j) / hs;
      for (let i = 0; i <= ws; i++) {
        const p = geo.ecef(lat, -180 + (360 * i) / ws);
        pos[k++] = p[0] * radius; pos[k++] = p[1] * radius; pos[k++] = p[2] * radius; uv[t++] = i / ws; uv[t++] = 1 - j / hs;
      }
    }
    const idx = new (nv > 65535 ? Uint32Array : Uint16Array)(ws * hs * 6); let q = 0;
    for (let j = 0; j < hs; j++) for (let i = 0; i < ws; i++) {
      const a = j * (ws + 1) + i, b = a + 1, c = a + ws + 1, d = c + 1;
      idx[q++] = a; idx[q++] = c; idx[q++] = b; idx[q++] = b; idx[q++] = c; idx[q++] = d;
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(pos, 3)); g.setAttribute('uv', new THREE.BufferAttribute(uv, 2)); g.setIndex(new THREE.BufferAttribute(idx, 1));
    return g;
  }
  L.buildSphereData = (ws, hs) => { const out = { pos: [], idx: [] }; for (let j = 0; j <= hs; j++) for (let i = 0; i <= ws; i++) out.pos.push(geo.ecef(90 - 180 * j / hs, -180 + 360 * i / ws)); for (let j = 0; j < hs; j++) for (let i = 0; i < ws; i++) { const a = j * (ws + 1) + i, b = a + 1, c = a + ws + 1, d = c + 1; out.idx.push([a, c, b], [b, c, d]); } return out; };

  function makeStars(THREE, count, dpr) {
    let seed = 20261107; const rnd = () => (seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0) / 4294967296;
    const pos = new Float32Array(count * 3), col = new Float32Array(count * 3), size = new Float32Array(count), ph = new Float32Array(count);
    for (let i = 0; i < count; i++) {
      const z = rnd() * 2 - 1, t = rnd() * Math.PI * 2, r = Math.sqrt(1 - z * z), rad = 3e6;
      pos[i * 3] = r * Math.cos(t) * rad; pos[i * 3 + 1] = z * rad; pos[i * 3 + 2] = r * Math.sin(t) * rad;
      const m = rnd(), tp = rnd(), b = 0.35 + rnd() * 0.65, c = tp < 0.3 ? [0.72, 0.82, 1] : tp < 0.8 ? [1, 1, 1] : [1, 0.86, 0.72];
      size[i] = m > 0.985 ? 3.8 : m > 0.9 ? 2.5 : 1.5 + rnd() * 0.6; ph[i] = rnd();
      col[i * 3] = c[0] * b; col[i * 3 + 1] = c[1] * b; col[i * 3 + 2] = c[2] * b;
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(pos, 3)); g.setAttribute('aColor', new THREE.BufferAttribute(col, 3));
    g.setAttribute('aSize', new THREE.BufferAttribute(size, 1)); g.setAttribute('aPh', new THREE.BufferAttribute(ph, 1));
    const mat = new THREE.ShaderMaterial({ vertexShader: SH.stars.vs, fragmentShader: SH.stars.fs, transparent: true, depthTest: false, depthWrite: false, blending: THREE.AdditiveBlending, uniforms: { uPR: { value: dpr }, uTime: { value: 0 } } });
    const p = new THREE.Points(g, mat); p.frustumCulled = false; p.renderOrder = 0; return p;
  }

  L.makeGlobe = function (THREE, canvas, profile) {
    const renderer = new THREE.WebGLRenderer({ canvas, antialias: profile.dpr < 1.5, alpha: false, powerPreference: 'high-performance' });
    renderer.setPixelRatio(profile.dpr); renderer.setClearColor(0x01030a, 1); renderer.sortObjects = true;
    const scene = new THREE.Scene(), camera = new THREE.PerspectiveCamera(35, 1, 0.0005, 1e7), size = { w: 1, h: 1 };
    const anis = Math.min(8, renderer.capabilities.getMaxAnisotropy ? renderer.capabilities.getMaxAnisotropy() : 1);
    const black = new THREE.DataTexture(new Uint8Array([0, 0, 0, 255]), 1, 1); black.needsUpdate = true;
    const mk = (o) => Object.assign({ transparent: false, depthTest: false, depthWrite: false }, o);
    const sphereGeo = buildSphere(THREE, R, profile.sphere[0], profile.sphere[1]);
    const cloudGeo = buildSphere(THREE, R * 1.0065, Math.max(48, profile.sphere[0] >> 1), Math.max(24, profile.sphere[1] >> 1));
    const atmoGeo = buildSphere(THREE, R * 1.14, 48, 24);

    /* Mọi lớp đều depthTest=false nên thứ tự vẽ chỉ do renderOrder quyết định — mà Three vẽ hết vật thể "opaque" TRƯỚC vật thể "transparent".
       Nếu Trái Đất là opaque thì sao (transparent, renderOrder 0) sẽ bị vẽ đè lên Trái Đất. Vì vậy Trái Đất cũng khai báo transparent (alpha luôn = 1, không blend). */
    const earthMat = new THREE.ShaderMaterial(mk({ vertexShader: SH.earth.vs, fragmentShader: SH.earth.fs, side: THREE.FrontSide, transparent: true, blending: THREE.NoBlending, uniforms: {
      uDay: { value: black }, uNight: { value: black }, uSun: { value: new THREE.Vector3(1, 0, 0) }, uCamObj: { value: new THREE.Vector3() }, uHasNight: { value: 0 } } }));
    const earth = new THREE.Mesh(sphereGeo, earthMat); earth.matrixAutoUpdate = false; earth.frustumCulled = false; earth.renderOrder = 10;

    const cloudMat = new THREE.ShaderMaterial(mk({ vertexShader: SH.clouds.vs, fragmentShader: SH.clouds.fs, transparent: true, side: THREE.FrontSide, uniforms: {
      uClouds: { value: black }, uHas: { value: 0 }, uTime: { value: 0 }, uFade: { value: 1 }, uRot: { value: 0 }, uSun: { value: new THREE.Vector3(1, 0, 0) } } }));
    const clouds = new THREE.Mesh(cloudGeo, cloudMat); clouds.matrixAutoUpdate = false; clouds.frustumCulled = false; clouds.renderOrder = 300; clouds.visible = !!profile.clouds;

    const atmoMat = new THREE.ShaderMaterial(mk({ vertexShader: SH.atmo.vs, fragmentShader: SH.atmo.fs, transparent: true, side: THREE.BackSide, blending: THREE.AdditiveBlending, uniforms: {
      uCenter: { value: new THREE.Vector3(0, 0, -R) }, uSunW: { value: new THREE.Vector3(1, 0, 0) }, uFade: { value: 1 } } }));
    const atmo = new THREE.Mesh(atmoGeo, atmoMat); atmo.frustumCulled = false; atmo.renderOrder = 310; atmo.position.set(0, 0, -R);

    const stars = profile.stars ? makeStars(THREE, profile.stars, profile.dpr) : null;
    const tileGroup = new THREE.Group(); tileGroup.frustumCulled = false;
    scene.add(earth, tileGroup, clouds, atmo); if (stars) scene.add(stars);
    const tp = L.makeTilePlane(THREE, tileGroup, { url: CFG.tiles.url, minZ: CFG.tiles.minZoom, maxZ: CFG.tiles.maxZoom, conc: profile.conc, bias: profile.bias, anisotropy: Math.min(4, anis) });

    const M = new THREE.Matrix4(), tmpV = new THREE.Vector3();
    let paused = false, lostCb = null;
    canvas.addEventListener('webglcontextlost', (e) => { e.preventDefault(); if (lostCb) lostCb(); });

    const api = {
      THREE, renderer, scene, camera, canvas, tilePlane: tp, sun: { lat: -14, lng: 112 },
      onLost(f) { lostCb = f; },
      resize(wc, hc) { size.w = Math.max(2, wc); size.h = Math.max(2, hc); renderer.setSize(size.w, size.h, false); camera.aspect = size.w / size.h; camera.updateProjectionMatrix(); },

      /* st: {lat,lng,range(km),tilt,heading,look}; time: giây (hoạt ảnh nền: sao nhấp nháy, mây trôi) */
      render(st, time) {
        if (paused) return;
        const aspect = size.w / size.h, boost = u.lerp(1, Math.max(1, 0.95 / aspect), u.sstep(1500, 6000, st.range));
        const view = { range: st.range * boost, tilt: st.tilt, heading: st.heading, look: st.look };
        const pose = geo.cameraPose(view), p = pose.pos;
        camera.position.set(p[0], p[1], p[2]); camera.up.set(pose.up[0], pose.up[1], pose.up[2]); camera.lookAt(pose.look[0], pose.look[1], pose.look[2]);
        camera.near = u.clamp(view.range * 0.0015, 0.0003, 20); camera.far = 1e7; camera.updateProjectionMatrix();

        const b = geo.basis(st.lat, st.lng), sunE = geo.ecef(api.sun.lat, api.sun.lng), sunW = geo.toEnu(sunE, b);
        M.set(b.E[0], b.E[1], b.E[2], 0, b.N[0], b.N[1], b.N[2], 0, b.U[0], b.U[1], b.U[2], 0, 0, 0, 0, 1); M.setPosition(0, 0, -R);   /* đủ 16 phần tử: ECEF → ENU, rồi tịnh tiến tâm Trái Đất về (0,0,-R) */
        earth.matrix.copy(M); earth.matrixWorldNeedsUpdate = true; clouds.matrix.copy(M); clouds.matrixWorldNeedsUpdate = true;
        const ce = [p[0], p[1], p[2] + R], co = [0, 1, 2].map((i) => ce[0] * b.E[i] + ce[1] * b.N[i] + ce[2] * b.U[i]);
        const alt = Math.hypot(ce[0], ce[1], ce[2]) - R;
        earthMat.uniforms.uCamObj.value.set(co[0], co[1], co[2]); earthMat.uniforms.uSun.value.set(sunE[0], sunE[1], sunE[2]);
        cloudMat.uniforms.uSun.value.set(sunE[0], sunE[1], sunE[2]); cloudMat.uniforms.uTime.value = time; cloudMat.uniforms.uRot.value = time * 0.0015;
        cloudMat.uniforms.uFade.value = u.sstep(450, 2500, alt);
        atmoMat.uniforms.uSunW.value.set(sunW[0], sunW[1], sunW[2]); atmoMat.uniforms.uFade.value = u.sstep(300, 2200, alt);
        if (stars) { stars.position.copy(camera.position); stars.material.uniforms.uTime.value = time; }
        tp.update(st, pose, size.h, 35, u.sstep(5200, 2400, st.range), 1 / (Math.max(st.range, 0.3) * 16), aspect);
        renderer.render(scene, camera);
        api.altitudeKm = alt;
      },

      /* chiếu một điểm lat/lng ra pixel màn hình (dùng để đặt marker đúng vị trí) */
      project(lat, lng, st) {
        const b = geo.basis(st.lat, st.lng), d = geo.ecef(lat, lng), t = geo.ecef(st.lat, st.lng);
        const e = geo.toEnu([(d[0] - t[0]) * R, (d[1] - t[1]) * R, (d[2] - t[2]) * R], b);
        tmpV.set(e[0], e[1], e[2]).project(camera);
        return { x: (tmpV.x * 0.5 + 0.5) * size.w, y: (-tmpV.y * 0.5 + 0.5) * size.h, visible: tmpV.z > -1 && tmpV.z < 1 };
      },

      setTexture(kind, tex) {
        tex.wrapS = THREE.RepeatWrapping; tex.anisotropy = anis; tex.needsUpdate = true;
        if (kind === 'day') { const o = earthMat.uniforms.uDay.value; earthMat.uniforms.uDay.value = tex; if (o && o !== black) o.dispose(); }
        if (kind === 'night') { earthMat.uniforms.uNight.value = tex; earthMat.uniforms.uHasNight.value = 1; }
        if (kind === 'clouds') { cloudMat.uniforms.uClouds.value = tex; cloudMat.uniforms.uHas.value = 1; }
      },
      setDpr(d) { api.dpr = d; renderer.setPixelRatio(d); renderer.setSize(size.w, size.h, false); },
      dpr: profile.dpr,
      pause() { paused = true; }, resume() { paused = false; }, get paused() { return paused; },
      stats() { return Object.assign({ calls: renderer.info.render.calls, tris: renderer.info.render.triangles, altKm: api.altitudeKm }, tp.stats()); },
      dispose() {
        tp.dispose(); [sphereGeo, cloudGeo, atmoGeo].forEach((g) => g.dispose()); [earthMat, cloudMat, atmoMat].forEach((m) => m.dispose());
        if (stars) { stars.geometry.dispose(); stars.material.dispose(); } renderer.dispose();
      }
    };

    /* ---- tải texture: nguồn thấp độ phân giải trước để mở màn sớm, bản cao nạp nền ---- */
    api.loadTextures = async function () {
      const T = CFG.textures, loader = new THREE.TextureLoader(); loader.setCrossOrigin('anonymous');
      const load = (url, ms) => u.withTimeout(new Promise((res, rej) => loader.load(url, res, undefined, () => rej(new Error('texture ' + url)))), ms || 14000, 'texture');
      const sized = (c, W) => c.url.replace('{w}', W).replace('{h}', W >> 1);
      let ok = false;
      for (const c of T.day) {
        try {
          const low = await load(sized(c, 1024), c.optional ? 4000 : 13000); api.setTexture('day', low); L.credits.add('day', c.credit); ok = true;
          if (profile.texW > 1024 && c.url.indexOf('{w}') > -1) load(sized(c, profile.texW), 30000).then((hi) => api.setTexture('day', hi)).catch(() => {});
          break;
        } catch (e) { /* thử nguồn kế tiếp */ }
      }
      if (!ok) throw new Error('Không tải được texture Trái Đất từ bất kỳ nguồn nào');
      const bg = async (kind, list, W) => { for (const c of list) { try { const t = await load(sized(c, W), 20000); api.setTexture(kind, t); L.credits.add(kind, c.credit); return true; } catch (e) { /* tiếp */ } } return false; };
      bg('night', T.night, Math.min(profile.texW, 2048)); if (profile.clouds) bg('clouds', T.clouds, 2048);
      return true;
    };
    return api;
  };
})(window);
