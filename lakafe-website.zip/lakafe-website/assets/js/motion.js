/* ============================================================================
 * LAKAFÉ — Chuyển động khi cuộn: hiện dần, chữ sáng dần theo cuộn, parallax, tiến trình từng "cảnh",
 * thanh điều hướng, menu di động, chế độ giảm chuyển động. Một vòng rAF duy nhất, chỉ đọc layout cho phần tử gần màn hình.
 * ========================================================================== */
(function (w) {
  'use strict';
  const L = w.LAKAFE, u = L.util, $ = u.$, $$ = u.$$;
  const M = (L.motion = {});
  const reduce = () => !!(w.matchMedia && w.matchMedia('(prefers-reduced-motion: reduce)').matches);
  const hasIO = 'IntersectionObserver' in w;

  M.reveal = function (root) {
    const els = $$('.rv:not(.in),.rv-fade:not(.in),.rv-clip:not(.in)', root);
    if (!hasIO) { els.forEach((e) => e.classList.add('in')); return; }
    const io = new IntersectionObserver((es) => es.forEach((e) => { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } }), { threshold: 0.1, rootMargin: '0px 0px -6% 0px' });
    els.forEach((e) => io.observe(e));
  };

  function splitWords(el) {
    const words = [];
    (function wrap(node) {
      Array.from(node.childNodes).forEach((n) => {
        if (n.nodeType === 3) {
          const frag = document.createDocumentFragment();
          n.textContent.split(/(\s+)/).forEach((t) => {
            if (!t) return;
            if (/^\s+$/.test(t)) frag.appendChild(document.createTextNode(' '));
            else { const s = document.createElement('span'); s.className = 'w'; s.textContent = t; frag.appendChild(s); words.push(s); }
          });
          n.replaceWith(frag);
        } else if (n.nodeType === 1) wrap(n);
      });
    })(el);
    return words;
  }

  function initSteps() {
    const steps = $$('.step');
    if (!hasIO) { steps.forEach((s) => s.classList.add('is-on')); return; }
    const io = new IntersectionObserver((es) => es.forEach((e) => e.target.classList.toggle('is-on', e.isIntersecting)), { rootMargin: '-38% 0px -38% 0px' });
    steps.forEach((s) => io.observe(s));
  }

  function initNav() {
    if (!hasIO) return;
    const map = {}; $$('.topbar nav a').forEach((a) => { map[a.getAttribute('href')] = a; });
    const io = new IntersectionObserver((es) => es.forEach((e) => { const a = map['#' + e.target.id]; if (a) a.classList.toggle('on', e.isIntersecting); }), { rootMargin: '-45% 0px -50% 0px' });
    ['cau-chuyen', 'thuc-don', 'ghe-tham'].forEach((id) => { const s = document.getElementById(id); if (s) io.observe(s); });
  }

  function initBurger() {
    const b = $('.burger'), nav = $('#mnav'); if (!b || !nav) return;
    const set = (on) => { document.body.classList.toggle('nav-open', on); b.setAttribute('aria-expanded', String(on)); b.setAttribute('aria-label', on ? 'Đóng menu' : 'Mở menu'); nav.setAttribute('aria-hidden', String(!on)); };
    b.addEventListener('click', () => set(!document.body.classList.contains('nav-open')));
    nav.addEventListener('click', (e) => { if (e.target.closest('a')) set(false); });
    w.addEventListener('keydown', (e) => { if (e.key === 'Escape' && document.body.classList.contains('nav-open')) set(false); });
    if (w.matchMedia) { const mq = w.matchMedia('(min-width: 821px)'); const f = (e) => { if (e.matches) set(false); }; if (mq.addEventListener) mq.addEventListener('change', f); else if (mq.addListener) mq.addListener(f); }
  }

  M.calm = function () {
    const btn = $('[data-calm]'); if (!btn) return;
    const apply = (on) => { document.body.classList.toggle('calm', on); document.documentElement.classList.toggle('no-smooth', on); btn.setAttribute('aria-pressed', String(on)); btn.textContent = 'Chế độ giảm chuyển động: ' + (on ? 'bật' : 'tắt'); };
    apply(!!L.store.local.get('calm', false) || reduce());
    btn.addEventListener('click', () => { const on = !document.body.classList.contains('calm'); L.store.local.set('calm', on); apply(on); });
  };

  /* hero rời màn hình → tạm dừng dựng địa cầu nền để tiết kiệm pin */
  function initHeroVisibility() {
    const hero = $('#top'); if (!hero || !hasIO) return;
    new IntersectionObserver((es) => es.forEach((e) => { if (L.journey) L.journey.setVisible(e.isIntersecting); }), { threshold: 0 }).observe(hero);
  }

  M.start = function () {
    const bar = $('#topbar'), hero = $('#top'), wEl = $('[data-words]'), words = wEl ? splitWords(wEl) : [], par = $$('[data-parallax]'), scenes = $$('.scene');
    initSteps(); initNav(); initBurger(); M.calm(); initHeroVisibility();
    let raf = 0, lastY = w.scrollY;
    const tick = () => {
      raf = 0; const vh = w.innerHeight, y = w.scrollY, hh = hero ? hero.offsetHeight : vh, calm = document.body.classList.contains('calm') || reduce();
      const solid = y > hh * 0.55; bar.classList.toggle('is-solid', solid);
      if (solid && y > lastY + 6 && !document.body.classList.contains('nav-open')) bar.classList.add('is-hidden');
      else if (y < lastY - 6 || !solid) bar.classList.remove('is-hidden');
      if (Math.abs(y - lastY) > 6) lastY = y;
      if (words.length) {
        const r = wEl.getBoundingClientRect();
        if (r.bottom > -120 && r.top < vh + 120) {
          const p = u.clamp((vh * 0.9 - r.top) / (r.height + vh * 0.35), 0, 1), k = p * (words.length + 7);
          words.forEach((s, i) => { const v = (0.14 + 0.86 * (calm ? 1 : u.clamp((k - i) / 7, 0, 1))).toFixed(2); if (s._o !== v) { s._o = v; s.style.setProperty('--o', v); } });
        }
      }
      par.forEach((el) => { const r = el.getBoundingClientRect(); if (r.bottom < -60 || r.top > vh + 60) return; el.style.setProperty('--py', u.clamp((vh - r.top) / (vh + r.height), 0, 1).toFixed(3)); });
      scenes.forEach((sc) => { const r = sc.getBoundingClientRect(); if (r.bottom < -60 || r.top > vh + 60) return; sc.style.setProperty('--sp', u.clamp(-r.top / Math.max(1, r.height - vh), 0, 1).toFixed(3)); });
    };
    const req = () => { if (!raf) raf = requestAnimationFrame(tick); };
    w.addEventListener('scroll', req, { passive: true }); w.addEventListener('resize', req); req();
  };
})(window);
