/* ============================================================================
 * LAKAFÉ — TilePlane: ảnh vệ tinh theo quadtree, "dán" lên mặt cầu bằng mặt phẳng tiếp tuyến
 * (hệ ENU, km, gốc = điểm mục tiêu) rồi uốn theo độ cong Trái Đất ngay trong vertex shader.
 *  • Chi tiết tăng dần theo khoảng cách camera (screen-space error) → "càng zoom càng nét".
 *  • Tile chưa tải xong → vẽ tile cha đã có (không bao giờ trống/đen); tile mới hiện dần (fade).
 *  • Rìa lớp ảnh được làm mờ dần về texture NASA bên dưới → không lộ viền chữ nhật.
 * Không dùng depth test: thứ tự vẽ theo cấp zoom (renderOrder = 100 + z).
 * ========================================================================== */
(function (w) {
  'use strict';
  const L = w.LAKAFE, u = L.util, geo = L.geo, R = geo.R, C = geo.C;

  const VERT = [
    'uniform float uR; varying vec2 vUv; varying vec3 vW;',
    'void main(){ vUv = uv; vec4 wp = modelMatrix * vec4(position, 1.0);',
    '  float d2 = dot(wp.xy, wp.xy); wp.z += -d2 / (uR + sqrt(max(uR*uR - d2, 0.0)));',
    '  vW = wp.xyz; gl_Position = projectionMatrix * viewMatrix * wp; }'
  ].join('\n');

  const FRAG = [
    'precision highp float;',
    'uniform sampler2D uMap; uniform float uAlpha, uMaster, uR0, uR1, uHaze, uSat; uniform vec3 uHazeCol;',
    'varying vec2 vUv; varying vec3 vW;',
    'void main(){',
    '  vec3 c = texture2D(uMap, vUv).rgb;',
    '  float a = uAlpha * uMaster * (1.0 - smoothstep(uR0, uR1, length(vW.xy)));',
    '  float hz = 1.0 - exp(-length(vW - cameraPosition) * uHaze);',
    '  c = mix(c, uHazeCol, hz * 0.62);',
    '  float l = dot(c, vec3(0.299, 0.587, 0.114)); c = mix(vec3(l), c, uSat);',
    '  gl_FragColor = vec4(c, a); }'
  ].join('\n');

  L.TILE_SHADERS = { VERT, FRAG };

  L.makeTilePlane = function (THREE, group, o) {
    o = Object.assign({ url: '', minZ: 5, maxZ: 17, conc: 6, bias: 0, maxTiles: 280, anisotropy: 4 }, o || {});
    const tiles = new Map();                 // "z/x/y" → record
    const geoms = {};                        // số đoạn → PlaneGeometry dùng chung
    const queue = []; let inflight = 0, frameNo = 0;
    const loader = new THREE.TextureLoader(); loader.setCrossOrigin('anonymous');
    const base = new THREE.ShaderMaterial({
      vertexShader: VERT, fragmentShader: FRAG, transparent: true, depthTest: false, depthWrite: false,
      uniforms: {
        uMap: { value: null }, uAlpha: { value: 0 }, uMaster: { value: 0 }, uR: { value: R }, uR0: { value: 100 }, uR1: { value: 200 },
        uHaze: { value: 0 }, uHazeCol: { value: new THREE.Color(0.66, 0.76, 0.88) }, uSat: { value: 1.04 }
      }
    });
    const seg = (z) => (z <= 9 ? 12 : z <= 11 ? 4 : 1);
    const geom = (n) => geoms[n] || (geoms[n] = new THREE.PlaneGeometry(1, 1, n, n));
    const key = (z, x, y) => z + '/' + x + '/' + y;

    function rec(z, x, y) {
      const k = key(z, x, y); let r = tiles.get(k);
      if (!r) { r = { k, z, x, y, state: 0, tex: null, mesh: null, t: 0, last: 0, prio: 0, d: 0, queued: false, shown: false }; tiles.set(k, r); }
      return r;
    }
    /* Độ ưu tiên = −(kích thước tile trên màn hình, px): tile phủ nhiều điểm ảnh nhất (thô, gần camera) tải trước, tile nhỏ/xa tải sau.
       Dọc theo một chuỗi tổ tiên thì tile cha luôn lớn hơn tile con nên vẫn "thô trước, mịn sau"; nhưng khác với xếp theo cấp zoom thuần túy,
       tile mịn ngay dưới điểm đến không phải chờ cả lớp tile thô ở xa/ngoài rìa màn hình. */
    function request(r, prio) {
      r.last = frameNo; r.prio = Math.min(r.queued ? r.prio : 1e9, prio);
      if (r.state === 0 && !r.queued) { r.queued = true; queue.push(r); }
    }
    function pump() {
      if (inflight >= o.conc || !queue.length) return;
      queue.sort((a, b) => a.prio - b.prio);                      // sắp một lần; lấy từ đầu hàng thì thứ tự vẫn giữ nguyên
      while (inflight < o.conc && queue.length) {
        const r = queue.shift(); r.queued = false;
        if (frameNo - r.last > 30 || r.state !== 0) { if (r.state === 0) tiles.delete(r.k); continue; }
        r.state = 1; inflight++;
        loader.load(geo.tileUrl(o.url, r.z, r.x, r.y), (tex) => {
          inflight--; tex.generateMipmaps = true; tex.anisotropy = o.anisotropy;
          if (!tiles.has(r.k)) { tex.dispose(); pump(); return; }
          r.tex = tex; r.state = 2; r.t = performance.now();
          const m = base.clone(); m.uniforms.uMap.value = tex; m.uniforms.uAlpha.value = 0;
          r.mesh = new THREE.Mesh(geom(seg(r.z)), m); r.mesh.frustumCulled = false; r.mesh.renderOrder = 100 + r.z; r.mesh.visible = false;
          group.add(r.mesh); pump();
        }, undefined, () => { inflight--; r.state = 3; r.t = performance.now(); pump(); });
      }
    }
    function evict() {
      if (tiles.size <= o.maxTiles) return;
      const cut = tiles.size > o.maxTiles * 1.5 ? 8 : 20;          // vượt xa trần → bỏ cả tile mới "nguội" gần đây (mỗi tile ~350 KB VRAM kể cả mipmap)
      const old = Array.from(tiles.values()).filter((r) => !r.shown && r.last < frameNo - cut).sort((a, b) => a.last - b.last);
      for (let i = 0; i < old.length && tiles.size > o.maxTiles * 0.8; i++) drop(old[i]);
    }
    function drop(r) {
      if (r.mesh) { group.remove(r.mesh); r.mesh.material.dispose(); }
      if (r.tex) r.tex.dispose();
      tiles.delete(r.k);
    }

    /* st: {lat,lng,range,tilt}  pose: cameraPose() (ENU)  viewH: chiều cao khung hình (px)  fov: độ  aspect: rộng/cao */
    function update(st, pose, viewH, fov, master, haze, aspect) {
      frameNo++;
      const active = st.range < 9000;
      tiles.forEach((r) => { r.shown = false; });
      if (!active) { tiles.forEach((r) => { if (r.mesh) r.mesh.visible = false; }); return; }

      const m = geo.mercFrac(st.lat, st.lng), cosL = Math.cos(st.lat * Math.PI / 180), K = C * cosL;
      const k = viewH / (2 * Math.tan(fov * Math.PI / 360)), cam = pose.pos;
      const lod = 1.4 * Math.pow(2, -o.bias), rcull = u.clamp(st.range * 3.4, 1.5, 1600);
      const show = new Set(), leaves = [];
      /* Chỉ tải tile nằm trong (hoặc sát) khung nhìn: góc lệch so với hướng nhìn ≤ nửa đường chéo FOV + dự phòng 7°.
         Nếu không, hàng nghìn tile phía sau/bên hông camera chen hàng đợi và tile nét nhất (ngay dưới quán) tải sau cùng. */
      const fw = [pose.look[0] - cam[0], pose.look[1] - cam[1], pose.look[2] - cam[2]], fl = Math.hypot(fw[0], fw[1], fw[2]) || 1;
      fw[0] /= fl; fw[1] /= fl; fw[2] /= fl;
      const halfDiag = Math.atan(Math.tan(fov * Math.PI / 360) * Math.sqrt(1 + Math.pow(aspect || 1.8, 2))) + 0.12;

      const visit = (z, x, y) => {
        const n = Math.pow(2, z); if (y < 0 || y >= n) return;
        const wk = K / n, x0 = (x / n - m.x) * K, y1 = -(y / n - m.y) * K, cx = x0 + wk / 2, cy = y1 - wk / 2;
        const dc = Math.hypot(cx, cy); if (dc - wk * 0.75 > rcull) return;
        const dx = cx - cam[0], dy = cy - cam[1], dz = -(dc * dc) / (2 * R) - cam[2];
        const dist = Math.sqrt(dx * dx + dy * dy + dz * dz), proj = wk / Math.max(dist - wk * 0.7, 1e-4) * k;
        /* hình cầu bao tile (bán kính 0,75·cạnh) nhìn từ camera có bán kính góc ar; nếu camera NẰM TRONG hình cầu đó (đang đứng trên tile) thì tile phủ cả bầu trời → không bao giờ loại */
        const rb = wk * 0.75, ang = Math.acos(u.clamp((dx * fw[0] + dy * fw[1] + dz * fw[2]) / Math.max(dist, 1e-6), -1, 1)), ar = dist <= rb * 1.05 ? Math.PI : Math.asin(rb / dist);
        if (ang - ar > halfDiag) return;                       // ngoài khung nhìn: không tải, không vẽ, không chia nhỏ
        const xw = ((x % n) + n) % n, r = rec(z, xw, y); request(r, -Math.min(proj, 1e6));
        if (z < o.maxZ && proj > 256 * lod) {
          for (let j = 0; j < 2; j++) for (let i = 0; i < 2; i++) visit(z + 1, 2 * x + i, 2 * y + j);
        } else leaves.push({ z, x, y, xw, cx, cy, wk });
      };
      const n0 = Math.pow(2, o.minZ), cx0 = Math.floor(m.x * n0), cy0 = Math.floor(m.y * n0);
      for (let j = -2; j <= 2; j++) for (let i = -2; i <= 2; i++) visit(o.minZ, cx0 + i, cy0 + j);

      /* chọn tile để vẽ: lá đã sẵn sàng, nếu chưa thì tổ tiên gần nhất đã sẵn sàng */
      const now = performance.now();
      leaves.forEach((lf) => {
        let z = lf.z, x = lf.xw, y = lf.y, r = null;
        for (; z >= o.minZ; z--, x >>= 1, y >>= 1) {
          const c = tiles.get(key(z, x, y));
          if (c && c.state === 2) { r = c; break; }
        }
        if (r) show.add(r);
      });
      const r0 = u.clamp(st.range * 2.2, 1.2, 900), r1 = r0 * 1.45;
      const hazeCol = null;
      show.forEach((r) => {
        r.shown = true;
        const n = Math.pow(2, r.z), wk = K / n, x0 = (r.x / n - m.x) * K, y1 = -(r.y / n - m.y) * K;
        let dxw = x0 + wk / 2; // xử lý vòng kinh độ khi xa
        const half = K / 2; if (dxw > half) dxw -= K; else if (dxw < -half) dxw += K;
        const me = r.mesh; me.visible = true; me.position.set(dxw, y1 - wk / 2, 0); me.scale.set(wk, wk, 1);
        const un = me.material.uniforms;
        un.uAlpha.value = u.clamp((now - r.t) / 380, 0, 1);
        un.uMaster.value = master; un.uR0.value = r0; un.uR1.value = r1; un.uHaze.value = haze;
      });
      tiles.forEach((r) => { if (r.mesh && !r.shown) r.mesh.visible = false; });
      pump(); evict();
    }

    return {
      update,
      stats: () => ({ total: tiles.size, shown: Array.from(tiles.values()).filter((r) => r.shown).length, inflight, queued: queue.length }),
      /* chẩn đoán: trạng thái chuỗi tile tổ tiên chứa điểm (lat,lng): z:trạng_thái[Q=đang xếp hàng][S=đang vẽ]@số_khung_kể_từ_lần_yêu_cầu_cuối */
      chain(lat, lng) {
        const m = geo.mercFrac(lat, lng), out = [];
        for (let z = o.minZ; z <= o.maxZ; z++) { const n = Math.pow(2, z), r = tiles.get(key(z, Math.floor(m.x * n), Math.floor(m.y * n))); out.push(z + ':' + (r ? ['new', 'load', 'ok', 'err'][r.state] + (r.queued ? 'Q' : '') + (r.shown ? 'S' : '') + '@' + (frameNo - r.last) : '-')); }
        return out.join(' ');
      },
      dispose() { Array.from(tiles.values()).forEach(drop); base.dispose(); Object.keys(geoms).forEach((k) => geoms[k].dispose()); }
    };
  };
})(window);
