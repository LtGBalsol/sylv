/* ============================================================================
 * LAKAFÉ — Nội dung website dựng từ dữ liệu: thống kê, "cảnh" câu chuyện, thực đơn, hộp thoại chi tiết,
 * liên hệ, bản đồ, lưu ý & nguồn. (Hiệu ứng cuộn nằm ở motion.js; khởi động ở main.js.)
 * ========================================================================== */
(function (w) {
  'use strict';
  const L = w.LAKAFE, u = L.util, $ = u.$, $$ = u.$$, MENU = w.LAKAFE_MENU, INFO = w.LAKAFE_INFO, LOC = w.LAKAFE_LOCATION, CFG = w.LAKAFE_CONFIG;
  const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const norm = (s) => String(s).normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/đ/g, 'd').replace(/Đ/g, 'd').toLowerCase().trim();
  const SHORT = { fda: 'FDA', nccih: 'NCCIH', 'nih-c': 'NIH ODS', uea: 'UEA' };
  const srcNo = {}, srcById = {};
  INFO.sources.forEach((s, i) => { srcNo[s.id] = i + 1; srcById[s.id] = s; });

  const S = (L.site = { cat: MENU.categories[0].id, query: '', trigger: null });

  const chip = (k) => { const g = INFO.ingredients[k]; return g ? '<span class="chip" data-tone="' + g.tone + '">' + esc(g.name) + '</span>' : ''; };
  const cite = (ids, direct) => (ids || []).filter((id) => srcNo[id]).sort((a, b) => srcNo[a] - srcNo[b]).map((id) =>
    '<sup class="cite"><a href="' + (direct ? srcById[id].url : '#src-' + id) + '"' + (direct ? ' target="_blank" rel="noopener"' : '') + ' aria-label="Nguồn ' + srcNo[id] + ': ' + esc(SHORT[id] || id) + '">[' + srcNo[id] + ']</a></sup>').join('');
  const allItems = () => { const out = []; MENU.categories.forEach((c) => c.items.forEach((it) => out.push({ it, cat: c }))); return out; };
  const findItem = (id) => allItems().find((x) => x.it.id === id);

  function priceHtml(it, cat) {
    if (cat.priceCols) return it.price.map((p, i) => (p == null ? '' : '<span>' + p + 'K<small>' + esc(cat.priceCols[i]) + '</small></span>')).join('');
    return it.price[0] + 'K';
  }

  /* ---------- thống kê ---------- */
  function renderStats() {
    const items = allItems(), prices = []; items.forEach((x) => x.it.price.forEach((p) => { if (p != null) prices.push(p); }));
    const set = (k, v) => { const e = $('[data-stat="' + k + '"]'); if (e) e.textContent = v; };
    set('items', items.length); set('cats', MENU.categories.length); set('range', Math.min.apply(null, prices) + '–' + Math.max.apply(null, prices));
  }

  /* ---------- các "cảnh" câu chuyện ---------- */
  function renderScenes() {
    const host = $('#scenes'); if (!host) return;
    const total = String(INFO.stories.length).padStart(2, '0');
    host.innerHTML = INFO.stories.map((s) => {
      const steps = s.steps.map((st, i) =>
        '<div class="step" data-i="' + i + '"><p class="step-k" data-n="' + (i + 1) + '">' + esc(st.k) + '</p>' +
        '<h3 class="display h-md">' + esc(st.h) + '</h3><p>' + esc(st.p) + cite(st.cite) + '</p>' +
        (st.chips ? '<div class="chips">' + st.chips.map(chip).join('') + '</div>' : '') +
        (st.facts ? '<ul class="facts">' + st.facts.map((f) => '<li>' + esc(f) + '</li>').join('') + '</ul>' : '') + '</div>').join('');
      return '<article class="scene" id="scene-' + s.id + '" data-tone="' + s.tone + '">' +
        '<div class="scene-bg" aria-hidden="true"><b>' + s.num + '</b></div>' +
        '<div class="container scene-grid">' +
          '<div class="scene-media"><figure class="media-frame" style="--ar:' + s.w + '/' + s.h + '"><img src="' + s.img + '" alt="' + esc(s.alt) + '" width="' + s.w + '" height="' + s.h + '" loading="lazy" decoding="async"></figure>' +
          '<div class="media-meter" aria-hidden="true"><span>' + s.num + ' / ' + total + '</span><span class="bar"><i></i></span></div></div>' +
          '<div class="scene-steps"><header class="scene-head"><p class="eyebrow">' + esc(s.eyebrow) + '</p><h2 class="display h-lg">' + esc(s.title) + '</h2>' +
          (s.cat ? '<a class="link-arrow" href="#thuc-don" data-goto-cat="' + s.cat + '">Xem trên thực đơn <span aria-hidden="true">→</span></a>' : '') + '</header>' + steps + '</div>' +
        '</div></article>';
    }).join('');
    $$('[data-goto-cat]', host).forEach((a) => a.addEventListener('click', () => S.selectCat(a.getAttribute('data-goto-cat'), true)));
  }

  /* ---------- thực đơn ---------- */
  function renderTabs() {
    const tabs = $('#menu-tabs'); if (!tabs) return;
    tabs.innerHTML = MENU.categories.map((c) => '<button class="tab" role="tab" type="button" id="tab-' + c.id + '" data-cat="' + c.id + '" aria-selected="false" aria-controls="menu-grid" tabindex="-1">' + esc(c.name) + '<sup>' + c.items.length + '</sup></button>').join('');
    tabs.addEventListener('click', (e) => { const b = e.target.closest('.tab'); if (b) S.selectCat(b.dataset.cat); });
    tabs.addEventListener('keydown', (e) => {
      if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft' && e.key !== 'Home' && e.key !== 'End') return;
      const list = $$('.tab', tabs), i = list.findIndex((t) => t.getAttribute('aria-selected') === 'true');
      const j = e.key === 'Home' ? 0 : e.key === 'End' ? list.length - 1 : u.mod(i + (e.key === 'ArrowRight' ? 1 : -1), list.length);
      e.preventDefault(); S.selectCat(list[j].dataset.cat); list[j].focus();
    });
  }

  function cardHtml(it, cat, d) {
    return '<button type="button" class="card pop' + (it.mark ? ' has-mark' : '') + '" style="--d:' + d.toFixed(2) + 's" data-id="' + it.id + '" aria-haspopup="dialog">' +
      '<span class="card-top">' + (it.mark ? '<span class="mark">' + esc(MENU.markLabel) + '</span>' : '') + '<span class="card-name">' + esc(it.name) + '</span></span>' +
      '<span class="card-chips">' + it.ing.slice(0, 3).map(chip).join('') + '</span>' +
      '<span class="card-foot"><span class="card-price">' + priceHtml(it, cat) + '</span><span class="card-go">Chi tiết</span></span></button>';
  }

  function renderGrid() {
    const grid = $('#menu-grid'), note = $('#menu-note'); if (!grid) return;
    const q = norm(S.query); let html = '', n = 0, lastGroup = null, count = 0;
    if (q) {
      MENU.categories.forEach((c) => {
        const hit = c.items.filter((it) => norm(it.name).indexOf(q) >= 0 || it.ing.some((k) => INFO.ingredients[k] && norm(INFO.ingredients[k].name).indexOf(q) >= 0));
        if (!hit.length) return; html += '<h3 class="grp">' + esc(c.name) + '</h3>';
        hit.forEach((it) => { html += cardHtml(it, c, Math.min(n++ * 0.035, 0.45)); count++; });
      });
      note.textContent = count ? 'Kết quả cho “' + S.query.trim() + '”: ' + count + ' món.' : '';
      if (!count) html = '<p class="menu-empty">Không tìm thấy món nào khớp “' + esc(S.query.trim()) + '”. Thử tên nguyên liệu khác (ví dụ: dâu, cacao, đào).</p>';
    } else {
      const c = MENU.categories.find((x) => x.id === S.cat) || MENU.categories[0];
      c.items.forEach((it) => { if (it.group && it.group !== lastGroup) { html += '<h3 class="grp">' + esc(it.group) + '</h3>'; lastGroup = it.group; } html += cardHtml(it, c, Math.min(n++ * 0.035, 0.45)); });
      note.textContent = c.lead + (c.priceNote ? ' ' + c.priceNote : '');
    }
    grid.innerHTML = html;
  }

  S.selectCat = function (id, noScroll) {
    if (!MENU.categories.some((c) => c.id === id)) return;
    S.cat = id; S.query = ''; const si = $('#menu-search'); if (si) si.value = '';
    $$('#menu-tabs .tab').forEach((t) => { const on = t.dataset.cat === id; t.setAttribute('aria-selected', on); t.tabIndex = on ? 0 : -1; if (on && !noScroll) { try { t.scrollIntoView({ block: 'nearest', inline: 'center', behavior: 'smooth' }); } catch (e) { /* ok */ } } });
    const grid = $('#menu-grid'); if (grid) grid.setAttribute('aria-labelledby', 'tab-' + id);
    renderGrid();
  };

  function initMenu() {
    renderTabs(); S.selectCat(S.cat, true);
    const leg = $('#menu-legend'); if (leg) leg.textContent = MENU.markNote + ' (nhãn “' + MENU.markLabel + '”).';
    const grid = $('#menu-grid'); grid.addEventListener('click', (e) => { const b = e.target.closest('.card'); if (b) S.openItem(b.dataset.id, b); });
    const si = $('#menu-search'); let tm = 0;
    si.addEventListener('input', () => { clearTimeout(tm); tm = setTimeout(() => { S.query = si.value; if (!S.query.trim()) { S.selectCat(S.cat, true); } else { renderGrid(); } }, 140); });
    si.addEventListener('keydown', (e) => { if (e.key === 'Escape') { si.value = ''; S.query = ''; S.selectCat(S.cat, true); } });
  }

  /* ---------- hộp thoại chi tiết món ---------- */
  function ingBlock(k) {
    const g = INFO.ingredients[k]; if (!g) return '';
    return '<div class="ing"><div class="ing-top">' + chip(k) + (g.alt ? '<small>' + esc(g.alt) + '</small>' : '') + '</div><p>' + esc(g.about) + '</p>' +
      (g.effects && g.effects.length ? '<ul>' + g.effects.map((e) => '<li>' + esc(e) + '</li>').join('') + '</ul>' : '') +
      (g.caution ? '<p class="caution">' + esc(g.caution) + '</p>' : '') +
      (g.cite && g.cite.length ? '<p class="ing-src">Tham khảo: ' + g.cite.filter((id) => srcById[id]).map((id) => '<a href="' + srcById[id].url + '" target="_blank" rel="noopener">' + esc(SHORT[id] || id) + '</a>').join(' · ') + '</p>' : '') + '</div>';
  }

  S.openItem = function (id, trigger) {
    const f = findItem(id), dlg = $('#item-dialog'); if (!f || !dlg) return;
    const it = f.it, cat = f.cat, used = [];
    $('#dlg-cat').textContent = cat.name + (it.group ? ' · ' + it.group : '');
    $('#dlg-title').innerHTML = esc(it.name) + (it.mark ? ' <span class="mark" style="vertical-align:middle;margin-left:10px">' + esc(MENU.markLabel) + '</span>' : '');
    $('#dlg-price').innerHTML = priceHtml(it, cat);
    $('#dlg-list').innerHTML = it.ing.map(ingBlock).join('');
    it.ing.forEach((k) => { const g = INFO.ingredients[k]; if (g && g.cite) g.cite.forEach((id2) => { if (used.indexOf(id2) < 0) used.push(id2); }); });
    $('#dlg-disc').textContent = INFO.disclaimer;
    $('#dlg-src').innerHTML = used.length ? '<span>Nguồn:</span>' + used.map((id2) => '<a href="' + srcById[id2].url + '" target="_blank" rel="noopener">[' + srcNo[id2] + '] ' + esc(srcById[id2].org.split(' — ')[0]) + '</a>').join('') : '';
    S.trigger = trigger || document.activeElement; dlg.classList.remove('closing');
    const box = $('.sheet-inner', dlg); if (box) box.scrollTop = 0;
    if (typeof dlg.showModal === 'function') { if (!dlg.open) dlg.showModal(); } else dlg.setAttribute('open', '');
    document.body.classList.add('dlg-open');
  };
  S.closeItem = function () {
    const dlg = $('#item-dialog'); if (!dlg || !(dlg.open || dlg.hasAttribute('open'))) return;
    dlg.classList.add('closing');
    setTimeout(() => {
      dlg.classList.remove('closing'); if (typeof dlg.close === 'function') dlg.close(); else dlg.removeAttribute('open');
      document.body.classList.remove('dlg-open'); const t = S.trigger; if (t && t.focus) { try { t.focus({ preventScroll: true }); } catch (e) { /* ok */ } }
    }, 260);
  };
  function initDialog() {
    const dlg = $('#item-dialog'); if (!dlg) return;
    dlg.addEventListener('click', (e) => { if (e.target === dlg || e.target.closest('[data-close]')) S.closeItem(); });
    dlg.addEventListener('cancel', (e) => { e.preventDefault(); S.closeItem(); });
    dlg.addEventListener('close', () => document.body.classList.remove('dlg-open'));
  }

  /* ---------- liên hệ, giờ mở cửa, sao chép địa chỉ ---------- */
  function initContact() {
    $$('[data-directions]').forEach((a) => { if (LOC.googleMapsUrl) a.href = LOC.googleMapsUrl; });
    $$('[data-addr]').forEach((e) => { e.textContent = LOC.address; });
    $$('[data-phone]').forEach((a) => { a.textContent = LOC.phone; a.href = 'tel:' + LOC.phoneIntl; });
    const hrs = $('#hours'); if (hrs) hrs.innerHTML = LOC.hours.map((h) => '<div><span>' + esc(h.days) + '</span><span>' + esc(h.time) + '</span></div>').join('');
    const cp = $('[data-copy-addr]');
    if (cp) cp.addEventListener('click', async () => {
      const old = cp.textContent; let ok = false;
      try { await navigator.clipboard.writeText(LOC.address); ok = true; } catch (e) {
        try { const ta = document.createElement('textarea'); ta.value = LOC.address; ta.style.cssText = 'position:fixed;opacity:0'; document.body.appendChild(ta); ta.select(); ok = document.execCommand('copy'); ta.remove(); } catch (e2) { /* ok */ }
      }
      cp.textContent = ok ? 'Đã sao chép ✓' : 'Hãy chọn và sao chép thủ công'; setTimeout(() => { cp.textContent = old; }, 2200);
    });
  }

  /* ---------- bản đồ vệ tinh khu vực (tải khi cuộn tới) ---------- */
  S.map = null;
  /* Chỉ nhận mã nhúng chính thức của Google Maps (Chia sẻ → Nhúng bản đồ); mọi URL khác bị bỏ qua. */
  function embedSrc(v) {
    v = String(v || '').trim(); const m = v.match(/src\s*=\s*["']([^"']+)["']/i); if (m) v = m[1];
    v = v.replace(/&amp;/g, '&'); return /^https:\/\/www\.google\.com\/maps\/embed(\/v1\/\w+)?\?/i.test(v) ? v : '';
  }
  async function initMap() {
    const host = $('#map-host'); if (!host || S.map) return;
    const st = $('#map-state'), sb = $('#map-status'), cr = $('#map-credit');
    const embed = embedSrc(LOC.googleEmbedUrl);
    if (embed) {                                           // bản đồ Google thật (mã nhúng chính thức, không cần API key) — giữ nguyên logo/attribution của Google
      S.map = { embed: true }; host.innerHTML = ''; $('#map-card').classList.add('is-embed');
      const f = document.createElement('iframe');
      f.src = embed; f.title = 'Bản đồ Google Maps — ' + LOC.name + ', ' + LOC.address; f.loading = 'lazy'; f.referrerPolicy = 'no-referrer-when-downgrade'; f.setAttribute('allowfullscreen', '');
      host.appendChild(f); return;
    }
    let loc = L.location.current();
    if (!loc) { try { loc = await u.withTimeout(L.location.resolve(), 8000, 'vị trí'); } catch (e) { loc = L.location.area(); } }
    const pin = !!loc.pin;
    S.map = new L.SatMap(host, { interactive: true, coop: true, view: { lat: loc.lat, lng: loc.lng, zoom: pin ? 17.2 : 13.4, heading: 0 } });
    if (pin) { const a = L.el('div', 'map-pin', '<i></i>'); S.map.addMarker(a, loc.lat, loc.lng); }
    st.textContent = pin ? (loc.state === 'confirmed' ? 'Vị trí quán đã xác nhận' : 'Vị trí tạm tính — chưa xác nhận') : 'Khu vực Thống Nhất, Đồng Nai';
    if (!pin) { sb.textContent = 'Bản đồ đang hiển thị khu vực. Để tới đúng cửa quán, hãy dùng nút “Chỉ đường” (ghim Google Maps của quán).'; sb.classList.add('on'); }
    cr.textContent = CFG.tiles.attribution;
  }
  function initMapLazy() {
    const card = $('#map-card'); if (!card) return;
    if (!('IntersectionObserver' in w)) { initMap(); return; }
    const io = new IntersectionObserver((es) => { if (es.some((e) => e.isIntersecting)) { io.disconnect(); initMap(); } }, { rootMargin: '300px 0px' });
    io.observe(card);
  }

  /* ---------- lưu ý & nguồn ---------- */
  function renderNotes() {
    const d = $('#disclaimer'); if (d) d.textContent = INFO.disclaimer;
    const ol = $('#src-list'); if (!ol) return;
    ol.innerHTML = INFO.sources.map((s) => '<li id="src-' + s.id + '"><a href="' + s.url + '" target="_blank" rel="noopener">' + esc(s.title) + '</a><small>' + esc(s.org) + ' — ' + esc(s.used) + '</small></li>').join('');
  }

  /* ---------- ghi nguồn động ---------- */
  function initCredits() {
    const e = $('[data-credit-dyn]'); if (!e) return;
    const f = (list) => { e.textContent = list.length ? 'Nguồn ảnh Trái Đất đã tải trong phiên này: ' + list.join(' · ') + '.' : ''; };
    f(L.credits.list()); L.bus.on('credits', f);
  }

  S.init = function () {
    [renderStats, renderScenes, initMenu, initDialog, initContact, renderNotes, initCredits, initMapLazy].forEach((fn) => { try { fn(); } catch (err) { console.error('[LAKAFE site]', fn.name, err); } });
  };
})(window);
