/* ============================================================================
 * LAKAFÉ — Google Maps 3D (Map3DElement / Photorealistic 3D Tiles qua Maps JavaScript API)
 * - Chỉ nạp khi có API key. Không tải/lưu tile Google thủ công; mọi dữ liệu đi qua API chính thức.
 * - Giữ nguyên logo + attribution do Google hiển thị (không che).
 * - Mọi lỗi (key sai, mạng, thiết bị yếu, thiếu dữ liệu) → reject để hành trình chuyển sang ảnh vệ tinh 2D.
 * ========================================================================== */
(function (w) {
  'use strict';
  const L = w.LAKAFE, u = L.util, CFG = w.LAKAFE_CONFIG;
  let loadP = null, authFailed = false;

  function bootstrap() {
    if (loadP) return loadP;
    loadP = new Promise((res, rej) => {
      if (!CFG.googleMapsApiKey) return rej(new Error('Chưa cấu hình googleMapsApiKey'));
      w.__lkGmapsReady = () => res(w.google.maps);
      w.gm_authFailure = () => { authFailed = true; rej(new Error('Google Maps từ chối API key (gm_authFailure) — kiểm tra referrer/billing/API đã bật')); };
      const s = document.createElement('script');
      s.src = 'https://maps.googleapis.com/maps/api/js?key=' + encodeURIComponent(CFG.googleMapsApiKey) +
        '&v=' + encodeURIComponent(CFG.googleMapsVersion || 'weekly') + '&loading=async&language=vi&region=VN&callback=__lkGmapsReady';
      s.async = true; s.onerror = () => rej(new Error('Không tải được Google Maps JavaScript API'));
      document.head.appendChild(s);
    });
    loadP.catch(() => {});
    return loadP;
  }

  L.google = {
    available() { return !!(CFG.googleMapsApiKey && CFG.google3d && CFG.google3d.enabled) && !authFailed; },
    preload() { return L.google.available() ? bootstrap() : Promise.reject(new Error('Google 3D tắt')); },
    async library(name) { await bootstrap(); return w.google.maps.importLibrary(name); },

    async elevation(lat, lng) {
      try {
        const lib = await u.withTimeout(L.google.library('elevation'), 5000, 'elevation');
        const r = await u.withTimeout(new lib.ElevationService().getElevationForLocations({ locations: [{ lat, lng }] }), 5000, 'elevation');
        const e = r && r.results && r.results[0] && r.results[0].elevation; return typeof e === 'number' ? e : 0;
      } catch (err) { return 0; }
    },

    /* Tạo phần tử 3D, trả về bộ điều khiển. cam: {lat,lng,alt,range(km),tilt,heading} */
    async create(container, cam) {
      const lib = await u.withTimeout(L.google.library('maps3d'), 12000, 'maps3d');
      if (!lib || !lib.Map3DElement) throw new Error('Map3DElement không có trên phiên bản API này');
      const mode = (lib.MapMode && lib.MapMode[CFG.google3d.mode]) || CFG.google3d.mode || 'SATELLITE';
      const el = new lib.Map3DElement({
        center: { lat: cam.lat, lng: cam.lng, altitude: cam.alt || 0 }, range: cam.range * 1000,
        tilt: cam.tilt, heading: cam.heading, mode, defaultUIHidden: true
      });
      el.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;display:block;';
      let errored = null;
      el.addEventListener('gmp-error', (e) => { errored = e; L.bus.emit('google:error', e); });
      container.appendChild(el);
      return {
        el, lib,
        get error() { return errored; },
        setCamera(c) {
          el.center = { lat: c.lat, lng: c.lng, altitude: c.alt || 0 };
          el.range = c.range * 1000; el.tilt = c.tilt; el.heading = c.heading;
        },
        steady(timeoutMs) {
          return new Promise((res) => {
            let done = false, t = 0;
            const fin = (v) => { if (done) return; done = true; clearTimeout(t); el.removeEventListener('gmp-steadychange', h); res(v); };
            const h = (e) => { const s = e && e.isSteady !== undefined ? e.isSteady : el.isSteady; if (s) fin(true); };
            el.addEventListener('gmp-steadychange', h); t = setTimeout(() => fin(false), timeoutMs || 4000);
            if (el.isSteady) fin(true);
          });
        },
        addMarker(lat, lng, label) {
          try {
            const m = new lib.Marker3DElement({ position: { lat, lng, altitude: 0 }, altitudeMode: (lib.AltitudeMode && lib.AltitudeMode.CLAMP_TO_GROUND) || 'CLAMP_TO_GROUND', label: label || 'LAKAFÉ', extruded: true });
            el.append(m); return m;
          } catch (e) { return null; }
        },
        destroy() { try { el.stopCameraAnimation && el.stopCameraAnimation(); } catch (e) { /* ok */ } el.remove(); }
      };
    }
  };
})(window);
