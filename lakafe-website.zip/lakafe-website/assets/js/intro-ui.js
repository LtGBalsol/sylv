/* ============================================================================
 * LAKAFÉ — Giao diện lớp intro: loader, HUD vệ tinh, thanh chặng, marker, "YOU HAVE ARRIVED"
 * ========================================================================== */
(function (w) {
  'use strict';
  const L = w.LAKAFE, u = L.util, CFG = w.LAKAFE_CONFIG;
  const fmt = (n, d) => n.toLocaleString('en-US', { minimumFractionDigits: d || 0, maximumFractionDigits: d || 0 });

  const UI = (L.introUI = {
    el: {}, stageIdx: -1, lastTele: 0,

    init() {
      const root = u.$('#intro'); if (!root) return false;
      const q = (s) => u.$(s, root), e = UI.el;
      Object.assign(e, {
        root, gl: q('#intro-gl'), g3d: q('#intro-g3d'), flat: q('#intro-flat'), skip: q('.hud-skip'),
        label: q('.hs-label'), sub: q('.hs-sub'), rail: q('.hud-rail'), tele: q('.hud-tele'), credit: q('.hud-credit'),
        marker: q('.lk-marker'), arrive: q('.arrive'), loader: q('.intro-loader'), bar: q('.il-bar i'), ltext: q('.il-text'), stageBox: q('.hud-stage')
      });
      e.rail.innerHTML = CFG.stages.map((s, i) => '<li data-i="' + i + '"><i></i><span>' + s.label + '</span></li>').join('');
      e.railItems = u.$$('li', e.rail);
      e.teleAlt = q('[data-k=alt]'); e.teleLat = q('[data-k=lat]'); e.teleLng = q('[data-k=lng]');
      /* Ghi nguồn ảnh luôn hiển thị ngay từ đầu (kể cả khi chạy chế độ bản đồ 2D, không có dòng "credits" của NASA), rồi bổ sung nguồn NASA khi đã tải */
      const showCredit = (list) => { e.credit.textContent = (list || L.credits.list()).concat([CFG.tiles.attribution]).join(' · '); };
      showCredit(); L.bus.on('credits', showCredit);
      /* Trong lúc hành trình chiếu (body.intro-active), phần trang phía sau bị che: khoá nó (inert) để bàn phím và trình đọc màn hình
         không "lạc" vào nội dung vô hình. Nguồn sự thật duy nhất là class intro-active nên mọi đường thoát (xong / bỏ qua / lỗi) đều tự mở khoá. */
      const sync = () => UI.lockPage(document.body.classList.contains('intro-active'));
      try { new MutationObserver(sync).observe(document.body, { attributes: true, attributeFilter: ['class'] }); } catch (err) { /* ok */ }
      sync();
      return true;
    },

    lockPage(on) {
      ['.skip-link', '#topbar', '#mnav', '#main', '.footer'].forEach((s) => { const n = u.$(s); if (n) { if (on) n.setAttribute('inert', ''); else n.removeAttribute('inert'); } });
      if (!on) {                                            // tiêu điểm đang nằm trong lớp intro (vừa biến mất) → đưa về nội dung chính, không cuộn
        const a = document.activeElement, r = UI.el.root, m = u.$('#main');
        if (r && m && a && a !== document.body && r.contains(a)) { try { m.focus({ preventScroll: true }); } catch (err) { /* ok */ } }
      }
    },

    loading(p, text) { const e = UI.el; if (e.bar) e.bar.style.transform = 'scaleX(' + u.clamp(p, 0, 1).toFixed(3) + ')'; if (text && e.ltext) e.ltext.textContent = text; },
    loaded() { const e = UI.el; e.root.classList.add('is-ready'); setTimeout(() => e.loader && e.loader.classList.add('is-gone'), 700); },

    stage(i) {
      const e = UI.el, s = CFG.stages[i]; if (!s || i === UI.stageIdx) return; UI.stageIdx = i;
      e.stageBox.classList.remove('swap'); void e.stageBox.offsetWidth; e.stageBox.classList.add('swap');
      e.label.textContent = s.label; e.sub.textContent = s.sub;
      e.railItems.forEach((li, k) => { li.classList.toggle('done', k < i); li.classList.toggle('on', k === i); });
    },

    telemetry(st, altKm, loc, now) {
      if (now - UI.lastTele < 120) return; UI.lastTele = now; const e = UI.el, d = loc && loc.pin ? 4 : 2;
      const alt = altKm >= 100 ? fmt(altKm, 0) + ' KM' : altKm >= 1 ? fmt(altKm, 1) + ' KM' : fmt(altKm * 1000, 0) + ' M';
      e.teleAlt.textContent = 'ALT ' + alt;
      e.teleLat.textContent = 'LAT ' + Math.abs(st.lat).toFixed(d) + '°' + (st.lat >= 0 ? 'N' : 'S');
      e.teleLng.textContent = 'LNG ' + Math.abs(st.lng).toFixed(d) + '°' + (st.lng >= 0 ? 'E' : 'W');
    },

    /* x,y: pixel trong khung intro; null → ẩn */
    marker(x, y, strength) {
      const m = UI.el.marker; if (x == null) { m.classList.remove('on'); return; }
      m.style.transform = 'translate3d(' + x.toFixed(1) + 'px,' + y.toFixed(1) + 'px,0)'; m.style.setProperty('--k', u.clamp(strength, 0, 1).toFixed(3)); m.classList.add('on');
    },
    markerPin(on) { UI.el.marker.classList.toggle('has-pin', !!on); },

    arrive(loc) {
      const e = UI.el, a = e.arrive;
      a.querySelector('.a1').textContent = loc.pin ? 'YOU HAVE ARRIVED AT' : 'YOU HAVE ARRIVED IN';
      const a2 = a.querySelector('.a2'); a2.textContent = loc.pin ? 'LAKAFÉ' : (loc.label || 'ĐỒNG NAI').toUpperCase(); a2.classList.toggle('long', a2.textContent.length > 12);
      a.querySelector('.a3').textContent = loc.pin ? w.LAKAFE_LOCATION.address : 'Vị trí chính xác của quán đang được xác nhận';
      e.root.classList.add('is-arrived'); a.classList.add('on'); UI.markerPin(loc.pin);
    },

    toHero() { UI.el.root.classList.add('is-bg'); UI.el.root.classList.remove('is-arrived'); },
    toIntro() { const r = UI.el.root; r.classList.remove('is-bg', 'is-arrived', 'is-gone'); UI.el.arrive.classList.remove('on'); UI.stageIdx = -1; UI.el.marker.classList.remove('on'); },
    hide() { UI.el.root.classList.add('is-gone'); },
    show() { UI.el.root.classList.remove('is-gone'); },
    setMode(m) { UI.el.root.setAttribute('data-mode', m); }
  });
})(window);
