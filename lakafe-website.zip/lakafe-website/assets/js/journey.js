/* ============================================================================
 * LAKAFÉ — HÀNH TRÌNH: SPACE → EARTH → ASIA → SOUTHEAST ASIA → VIETNAM → ĐỒNG NAI → GIA KIỆM → LAKAFÉ
 * Một "đồng hồ" duy nhất + một đường camera duy nhất (nội suy PCHIP, vận tốc liên tục),
 * ba bộ dựng đọc cùng một trạng thái camera:
 *   globe  = Three.js (NASA Blue Marble + lớp ảnh vệ tinh theo quadtree)  ← mặc định
 *   google = Google Maps 3D, crossfade có kiểm soát từ globe khi đã "steady"
 *   flat   = ảnh vệ tinh 2D (SatMap) khi thiết bị không có WebGL / Three.js không tải được
 * Không bao giờ nhảy cảnh: Google chỉ hiện sau khi đã dựng xong đúng tư thế camera hiện tại.
 * ========================================================================== */
(function (w) {
  'use strict';
  const L = w.LAKAFE, u = L.util, geo = L.geo, CFG = w.LAKAFE_CONFIG, UI = L.introUI;
  const J = (L.journey = { status: 'idle', ctx: null });
  const BASE_T = [0, 2.4, 5.6, 8.2, 10.8, 14.2, 17.2, 20.6];   // giây tại mỗi chặng (trước khi nhân speed)

  /* ---------------- đường camera ---------------- */
  function buildTimeline(loc, o) {
    const F = CFG.frames, S = o.speed, pin = !!loc.pin;
    const rF = pin ? 0.5 : 6, tiltF = o.google ? CFG.google3d.finalTilt : CFG.intro.finalTilt;
    const orbit = (pin ? CFG.intro.orbitDegrees : 30) * (o.calm ? 0.25 : 1);
    const kf = [
      { lat: 15, lng: 172, range: 52000, tilt: 0, heading: 0, look: 1 },
      { lat: 16, lng: 150, range: 23000, tilt: 0, heading: 0, look: 1 },
      { lat: F.asia.lat, lng: F.asia.lng, range: 9200, tilt: 5, heading: 0, look: 0.8 },
      { lat: F.sea.lat, lng: F.sea.lng, range: 3700, tilt: 14, heading: 8, look: 0.2 },
      { lat: F.vietnam.lat, lng: F.vietnam.lng, range: 1750, tilt: 22, heading: 16, look: 0 },
      { lat: loc.lat, lng: loc.lng, range: 150, tilt: 34, heading: 38, look: 0 },
      { lat: loc.lat, lng: loc.lng, range: pin ? 13 : 60, tilt: 46, heading: 74, look: 0 },
      { lat: loc.lat, lng: loc.lng, range: rF, tilt: tiltF, heading: 118, look: 0 }
    ];
    const ts = BASE_T.map((t) => t * S), tOrbit = ts[7] + 7.5 * S, last = kf[7];
    const T = [-1.2 * S].concat(ts, [tOrbit, tOrbit + 1.4 * S]);
    const rows = [kf[0]].concat(kf, [Object.assign({}, last, { heading: last.heading + orbit })]);
    rows.push(rows[rows.length - 1]);
    const ch = (k, f) => L.pchip(T, rows.map((r) => (f ? f(r[k]) : r[k])));
    const fLat = ch('lat'), fLng = ch('lng'), fR = ch('range', Math.log), fTilt = ch('tilt'), fHead = ch('heading'), fLook = ch('look');
    const tEnd = T[T.length - 1], hEnd = rows[rows.length - 1].heading, idle = 1.6;
    const hi = Math.max(0, CFG.stages.findIndex((s) => s.id === CFG.google3d.handoffStage));
    return {
      ts, T, tArrive: ts[7], tHandoff: ts[hi], tEnd,
      at(t) {
        const tt = Math.min(t, tEnd);
        return { lat: fLat(tt), lng: fLng(tt), range: Math.exp(fR(tt)), tilt: fTilt(tt), heading: t > tEnd ? hEnd + (t - tEnd) * idle * (o.calm ? 0.3 : 1) : fHead(tt), look: u.clamp(fLook(tt), 0, 1) };
      },
      stageAt(t) { const lead = 0.45 * S; let k = 0; for (let i = 0; i < ts.length; i++) if (t >= ts[i] - lead) k = i; return k; }
    };
  }

  /* ---------------- chuẩn bị tài nguyên ---------------- */
  async function prepare(dev) {
    const P = { mode: 'none', globe: null, loc: null }, maxMs = CFG.intro.maxLoadSeconds * 1000, pr = { three: 0, tex: 0, loc: 0 };
    const upd = (t) => UI.loading(0.04 + 0.92 * (pr.three * 0.3 + pr.tex * 0.45 + pr.loc * 0.25), t);
    UI.loading(0.04, 'Đang chuẩn bị hành trình…');
    if (dev.profile.google && L.google.available()) L.google.preload().catch(() => {});
    const locP = L.location.resolve().then((l) => { pr.loc = 1; upd('Đang xác định vị trí quán…'); return l; });
    let abandoned = false;
    const globeP = dev.tier === 'none' ? Promise.resolve(null) : (async () => {
      const THREE = await L.load.module(CFG.cdn.three, { timeout: 11000 }); pr.three = 1; upd('Đang dựng Trái Đất…');
      const globe = L.makeGlobe(THREE, UI.el.gl, dev.profile);
      if (abandoned) { globe.dispose(); return null; }
      await globe.loadTextures(); pr.tex = 1; upd('Đang tải ảnh NASA…');
      if (abandoned) { globe.dispose(); return null; }
      return globe;
    })();
    globeP.catch(() => {});
    const loc = await u.withTimeout(locP, 7000, 'xác định vị trí').catch(() => L.location.area());
    try { P.globe = await u.withTimeout(globeP, maxMs, 'tải địa cầu'); } catch (e) { abandoned = true; console.info('[LAKAFE] Không dựng được địa cầu 3D → dùng ảnh vệ tinh 2D.', e && e.message); }
    P.loc = loc;
    if (P.globe) P.mode = 'globe';
    else {
      try { await u.withTimeout(L.load.image(geo.tileUrl(CFG.tiles.url, 4, 12, 6)), 6000, 'tile thử'); P.mode = 'flat'; } catch (e) { P.mode = 'none'; }
    }
    return P;
  }

  /* ---------------- chạy ---------------- */
  J.start = async function (opts) {
    opts = opts || {};
    if (J.status === 'loading' || J.status === 'running') return;
    if (!UI.el.root && !UI.init()) return;
    const dev = L.device.detect(), calm = !!(dev.reduceMotion || L.store.local.get('calm', false) || opts.calm);
    J.status = 'loading'; UI.toIntro(); UI.show(); UI.setMode('loading');
    document.body.classList.add('intro-active'); document.body.classList.remove('intro-done');
    const P = await prepare(dev);
    if (J.status !== 'loading') { if (P.globe) P.globe.dispose(); return; }          // người dùng đã SKIP khi đang tải
    if (P.mode === 'none') { console.info('[LAKAFE] Không có dữ liệu để dựng hành trình → hiển thị website.'); J.finish(false, 'no-data'); return; }

    const speed = (CFG.intro.speed || 1) * (calm ? 1.35 : 1) * (dev.tier === 'low' ? 0.9 : 1);
    const googleOK = P.mode === 'globe' && dev.profile.google && L.google.available();
    const tl = buildTimeline(P.loc, { speed, calm, google: googleOK });
    const c = (J.ctx = {
      P, tl, dev, calm, mode: P.mode, loc: P.loc, globe: P.globe, t: P.mode === 'flat' ? tl.ts[2] - 0.7 * speed : 0, last: performance.now(), frames: 0, ema: 0.016,
      stopped: false, arrived: false, revealed: false, visible: true, paused: !!opts.freeze, g: { state: 'idle', ctl: null, liveAt: 0 }, flat: null, W: 1, H: 1, raf: 0, dprSteps: 0, parity: 0
    });
    c.onResize = () => resize(c); w.addEventListener('resize', c.onResize);
    if (P.mode === 'flat') initFlat(c);
    resize(c);
    UI.setMode(P.mode); render(c, c.tl.at(c.t));       // dựng khung đầu để biên dịch shader trước khi mở màn
    UI.loading(1, 'Sẵn sàng'); UI.loaded(); J.status = 'running';
    document.addEventListener('visibilitychange', (c.onVis = () => { c.last = performance.now(); }));
    c.raf = requestAnimationFrame((n) => loop(c, n));
    L.bus.emit('journey:start', { mode: P.mode, loc: P.loc });
  };

  function resize(c) {
    const r = UI.el.root.getBoundingClientRect(); c.W = Math.max(2, Math.round(r.width)); c.H = Math.max(2, Math.round(r.height));
    if (c.globe) c.globe.resize(c.W, c.H);
  }

  function initFlat(c) {
    const box = UI.el.flat; box.innerHTML = ''; const tilt = L.el('div', 'flat-tilt'); box.appendChild(tilt);
    c.flatTilt = tilt; c.flat = new L.SatMap(tilt, { manual: true, overscan: FLAT_OVERSCAN, prefetchDeeper: true, bias: c.dev.profile.bias, view: { lat: 20, lng: 100, zoom: 4 } });
  }

  /* ---------------- vòng lặp ---------------- */
  function loop(c, now) {
    if (c.stopped) return;
    c.raf = requestAnimationFrame((n) => loop(c, n));
    if (c.revealed) { if (!c.visible || document.hidden) { c.last = now; return; } c.parity ^= 1; if (c.parity) return; }   // hero: 30 fps cho tiết kiệm pin
    const dt = Math.min(0.1, (now - c.last) / 1000); c.last = now;
    c.ema += (dt - c.ema) * 0.06;
    if (!c.paused) c.t += dt;
    try { frame(c, now); } catch (e) { console.error('[LAKAFE] lỗi khung hình:', e); degrade(c, e); }
  }

  function frame(c, now) {
    const tl = c.tl; let st = tl.at(c.t);
    if (!c.calm) { st = Object.assign({}, st, { heading: st.heading + 0.35 * Math.sin(c.t * 0.7) + 0.2 * Math.sin(c.t * 1.9), tilt: Math.max(0, st.tilt + 0.25 * Math.sin(c.t * 0.9)) }); }
    c.st = st;
    googleStep(c, st);
    render(c, st);
    const k = tl.stageAt(c.t); if (!c.revealed) UI.stage(k);
    UI.telemetry(st, c.globe && c.globe.altitudeKm != null ? c.globe.altitudeKm : st.range * Math.cos(st.tilt * Math.PI / 180), c.loc, now);
    placeMarker(c, st);
    if (!c.arrived && c.t >= tl.tArrive) { c.arrived = true; UI.arrive(c.loc); L.bus.emit('journey:arrive', c.loc); if (c.g.state === 'live' && c.loc.pin && c.g.ctl) c.g.ctl.addMarker(c.loc.lat, c.loc.lng, 'LAKAFÉ'); }
    if (!c.revealed && c.t >= tl.tArrive + 2.9 * (CFG.intro.speed || 1)) reveal(c);
    adapt(c);
  }

  function render(c, st) {
    if (c.mode === 'globe') {
      const sun = c.globe.sun; sun.lat = -14; sun.lng = 118 - c.t * 0.35;
      c.globe.render(st, c.t);
    } else if (c.mode === 'flat') {
      const z = Math.min(geo.zoomFromRange(st.range, st.lat, c.H, 35), CFG.tiles.maxZoom + 0.9);
      c.flat.setView({ lat: st.lat, lng: st.lng, zoom: Math.max(2.2, z), heading: st.heading }); c.flat.draw();
      { const tl = Math.min(st.tilt, 48); c.flatTilt.style.transform = 'perspective(' + TILT_D + 'px) rotateX(' + tl.toFixed(2) + 'deg) scale(' + tiltCover(c.H, tl, FLAT_OVERSCAN).toFixed(3) + ')'; }
    }
  }

  /* Chế độ dự phòng 2D: khi nghiêng, mép xa của tấm bản đồ lùi vào và nhỏ lại → phải phóng đủ để mép đó vẫn chạm mép trên của khung.
     Tính bằng hình học (không phỏng đoán): mép xa nằm ở độ sâu z = h·sinθ, chiếu lên màn hình ở y = h·cosθ·d/(d+h·sinθ); đặt y = H/2 rồi giải ra h. */
  const TILT_D = 1400, FLAT_OVERSCAN = 1.55;
  function tiltCover(H, deg, os) {
    const th = deg * Math.PI / 180, hh = H / 2;
    if (th < 0.002) return 1;
    const den = TILT_D * Math.cos(th) - hh * Math.sin(th);
    if (den <= TILT_D * 0.12) return 2.4;
    return Math.min(2.4, Math.max(1, (hh * TILT_D / den) / (hh * os)) * 1.03);
  }

  function placeMarker(c, st) {
    const tl = c.tl, k = u.sstep(tl.tArrive - 2.2, tl.tArrive - 0.2, c.t);
    if (k <= 0.01 || c.t < tl.ts[5]) { UI.marker(null); return; }
    let x = c.W / 2, y = c.H / 2;
    if (c.mode === 'globe' && c.g.state !== 'live') { const p = c.globe.project(c.loc.lat, c.loc.lng, st); if (!p.visible) { UI.marker(null); return; } x = p.x; y = p.y; }
    UI.marker(x, y, k);
  }

  /* ---------------- Google 3D: khởi tạo sớm, chỉ crossfade khi "steady" ---------------- */
  function googleStep(c, st) {
    const g = c.g, tl = c.tl, G = CFG.google3d;
    if ((c.mode !== 'globe' && c.mode !== 'google') || g.state === 'failed' || !L.google.available() || !c.dev.profile.google) return;
    if (g.state === 'idle' && c.t >= tl.tHandoff - G.prewarmSeconds) { g.state = 'loading'; startGoogle(c); }
    if (g.state === 'ready' && c.t >= tl.tHandoff) {
      g.state = 'live'; g.liveAt = c.t; UI.el.g3d.classList.add('is-live'); L.bus.emit('journey:google', 'live');
    }
    if (g.state === 'loading' && c.t > tl.tHandoff + 2.6) failGoogle(c, 'quá hạn chuẩn bị');
    if (g.state === 'live') {
      g.ctl.setCamera({ lat: st.lat, lng: st.lng, alt: g.alt || 0, range: st.range, tilt: st.tilt, heading: st.heading });
      if (g.ctl.error) { failGoogle(c, 'gmp-error'); return; }
      if (c.globe && !c.globe.paused && c.t - g.liveAt > 1.4) { c.globe.pause(); UI.el.gl.classList.add('is-off'); }   // crossfade xong → ngừng dựng Three
    }
  }
  async function startGoogle(c) {
    const g = c.g;
    try {
      const pose = c.tl.at(c.tl.tHandoff);
      g.alt = c.loc.pin ? (w.LAKAFE_LOCATION.groundAltitudeMeters != null ? w.LAKAFE_LOCATION.groundAltitudeMeters : await L.google.elevation(c.loc.lat, c.loc.lng)) : 0;
      g.ctl = await L.google.create(UI.el.g3d, { lat: pose.lat, lng: pose.lng, alt: 0, range: pose.range, tilt: pose.tilt, heading: pose.heading });
      const ok = await g.ctl.steady(CFG.google3d.steadyTimeoutMs);
      if (c.stopped) return; if (!ok || g.ctl.error) throw new Error('Google 3D chưa ổn định/không có dữ liệu');
      g.state = 'ready'; if (c.t >= c.tl.tHandoff) { g.state = 'ready'; }
    } catch (e) { failGoogle(c, e && e.message); }
  }
  function failGoogle(c, why) {
    const g = c.g; console.info('[LAKAFE] Google 3D không dùng được (' + why + ') → tiếp tục bằng ảnh vệ tinh.');
    const wasLive = g.state === 'live'; g.state = 'failed'; UI.el.g3d.classList.remove('is-live');
    if (g.ctl) { g.ctl.destroy(); g.ctl = null; }
    if (wasLive && c.globe) { UI.el.gl.classList.remove('is-off'); c.globe.resume(); }
    L.bus.emit('journey:google', 'failed');
  }

  /* ---------------- thích ứng hiệu năng ---------------- */
  function adapt(c) {
    c.frames++;
    if (c.mode !== 'globe' || c.revealed || c.frames < 90 || c.dprSteps >= 2 || c.frames % 60) return;
    if (c.ema > 0.034) { c.dprSteps++; c.globe.setDpr(Math.max(1, c.globe.dpr * 0.8)); c.ema = 0.016; }
  }

  function degrade(c, err) {
    if (c.mode === 'globe' && !c.degraded) {
      c.degraded = true; try { c.globe.dispose(); } catch (e) { /* ok */ } c.globe = null; UI.el.gl.classList.add('is-off');
      if (c.g.state !== 'live') { c.mode = 'flat'; initFlat(c); UI.setMode('flat'); } else { c.mode = 'google'; }
    } else if (c.mode === 'flat') { J.finish(false, 'render-error'); }
  }

  /* ---------------- chuyển cảnh sang website ---------------- */
  function reveal(c) {
    c.revealed = true; J.status = 'hero'; UI.toHero();
    document.body.classList.remove('intro-active'); document.body.classList.add('intro-done');
    L.store.session.set('seen', true); L.bus.emit('journey:reveal', c.loc);
  }

  /* ---------------- kết thúc / bỏ qua / phát lại ---------------- */
  function cleanup() {
    const c = J.ctx; if (!c) return; c.stopped = true; cancelAnimationFrame(c.raf);
    w.removeEventListener('resize', c.onResize); document.removeEventListener('visibilitychange', c.onVis);
    if (c.g.ctl) { try { c.g.ctl.destroy(); } catch (e) { /* ok */ } }
    if (c.globe) { try { c.globe.dispose(); } catch (e) { /* ok */ } }
    if (c.flat) { c.flat.destroy(); UI.el.flat.innerHTML = ''; }
    UI.el.g3d.classList.remove('is-live'); UI.el.gl.classList.remove('is-off'); J.ctx = null;
  }
  J.finish = function (watched, why) {
    cleanup(); UI.hide(); J.status = 'done';
    document.body.classList.remove('intro-active'); document.body.classList.add('intro-done', watched ? 'intro-watched' : 'intro-skipped');
    L.store.session.set('seen', true); L.bus.emit('journey:end', { watched, why });
  };
  J.skip = function () { if (J.status === 'idle' || J.status === 'done') return; J.finish(false, 'skip'); };
  J.replay = function (opts) {
    if (J.status === 'running' || J.status === 'loading' || J.status === 'hero') { cleanup(); }
    J.status = 'idle'; document.body.classList.remove('intro-skipped', 'intro-watched'); w.scrollTo(0, 0);
    return J.start(Object.assign({ replay: true }, opts));
  };
  J.setVisible = function (v) { if (J.ctx) J.ctx.visible = v; };
  J.seek = function (t) {            // công cụ kiểm thử/ghi hình: đứng yên tại thời điểm t rồi dựng 1 khung
    const c = J.ctx; if (!c) return null; c.paused = true; c.t = t; frame(c, performance.now()); return c.tl.at(t);
  };
})(window);
