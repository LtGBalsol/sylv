/* ============================================================================
 * LAKAFÉ — SatMap: bản đồ ảnh vệ tinh 2D (canvas), zoom liên tục + xoay.
 * Dùng cho: (1) phương án thay thế khi không có Google 3D / WebGL,
 *           (2) công cụ xác nhận tọa độ (?verify=1), (3) mục "Ghé quán".
 * Ảnh: Esri World Imagery (có ghi nguồn). Không đụng tới tile của Google.
 * ========================================================================== */
(function (w) {
  'use strict';
  const L = w.LAKAFE, u = L.util, geo = L.geo, D2R = Math.PI / 180;

  /* ---- bộ tải tile dùng chung: hàng đợi ưu tiên + giới hạn song song + LRU ---- */
  const TL = {
    max: 8, inflight: 0, q: [], map: new Map(), frame: 0, listeners: new Set(),
    get(url, prio, d) {
      let e = TL.map.get(url);
      if (!e) { e = { url, img: null, ready: false, loading: false, err: 0, t: 0, last: 0, prio, d, queued: false }; TL.map.set(url, e); }
      e.last = TL.frame;
      if (!e.ready && !e.loading && !(e.err && performance.now() - e.err < 20000)) {
        e.prio = Math.min(e.prio, prio); e.d = d;
        if (!e.queued) { e.queued = true; TL.q.push(e); }
        TL.pump();
      }
      return e;
    },
    pump() {
      while (TL.inflight < TL.max && TL.q.length) {
        TL.q.sort((a, b) => a.prio - b.prio || a.d - b.d);
        const e = TL.q.shift(); e.queued = false;
        if (TL.frame - e.last > 40) continue;      // đã lỗi thời (người dùng đã bay đi chỗ khác)
        TL.start(e);
      }
    },
    start(e) {
      e.loading = true; TL.inflight++;
      const im = new Image(); im.crossOrigin = 'anonymous'; im.decoding = 'async';
      im.onload = () => { e.img = im; e.ready = true; e.loading = false; e.t = performance.now(); TL.inflight--; TL.pump(); TL.listeners.forEach((f) => f(e)); };
      im.onerror = () => { e.loading = false; e.err = performance.now(); TL.inflight--; TL.pump(); };
      im.src = e.url;
    },
    evict() {
      if (TL.map.size <= 460) return;
      const arr = Array.from(TL.map.values()).sort((a, b) => a.last - b.last);
      for (let i = 0; i < arr.length - 320; i++) if (arr[i].last < TL.frame - 8) TL.map.delete(arr[i].url);
    }
  };
  L.tileLoader = TL;

  class SatMap {
    constructor(container, opt) {
      const cfg = (w.LAKAFE_CONFIG && w.LAKAFE_CONFIG.tiles) || {};
      this.opt = Object.assign({
        tileUrl: cfg.url, minZoom: 2, maxNative: cfg.maxZoom || 17, maxZoom: (cfg.maxZoom || 17) + 2,
        interactive: false, coop: false, manual: false, bias: 0, overscan: 1,
        background: '#0a0f12', prefetchDeeper: false, onClick: null, onView: null
      }, opt || {});
      this.box = container;
      this.view = Object.assign({ lat: 11, lng: 107, zoom: 5, heading: 0 }, this.opt.view || {});
      this.canvas = L.el('canvas', 'satmap-canvas');
      this.canvas.setAttribute('aria-hidden', 'true');
      this.layer = L.el('div', 'satmap-markers');
      this.box.appendChild(this.canvas); this.box.appendChild(this.layer);
      this.ctx = this.canvas.getContext('2d', { alpha: false });
      this.markers = []; this.dirty = true; this.raf = 0; this.pointers = new Map();
      this.dpr = Math.min(w.devicePixelRatio || 1, (L.device.detect().profile.dpr || 1.5));
      this._tileListener = () => this.invalidate(); TL.listeners.add(this._tileListener);
      this._ro = 'ResizeObserver' in w ? new ResizeObserver(() => this.resize()) : null;
      if (this._ro) this._ro.observe(this.box); else w.addEventListener('resize', (this._rs = () => this.resize()));
      if (this.opt.interactive) this.bind();
      this.resize();
    }

    resize() {
      /* clientWidth/clientHeight = kích thước bố cục, KHÔNG bị ảnh hưởng bởi CSS transform (getBoundingClientRect thì có —
         chế độ phẳng nghiêng bằng perspective/rotateX nên nếu dùng rect sẽ vẽ canvas thiếu và lệch). */
      const os = this.opt.overscan, br = this.box.getBoundingClientRect();
      const r = { width: this.box.clientWidth || br.width, height: this.box.clientHeight || br.height };
      this.W = Math.max(2, Math.round(r.width * os)); this.H = Math.max(2, Math.round(r.height * os));
      this.canvas.width = Math.round(this.W * this.dpr); this.canvas.height = Math.round(this.H * this.dpr);
      this.canvas.style.width = this.W + 'px'; this.canvas.style.height = this.H + 'px';
      if (os !== 1) { this.canvas.style.left = (-(os - 1) / 2 * r.width) + 'px'; this.canvas.style.top = (-(os - 1) / 2 * r.height) + 'px'; this.layer.style.left = this.canvas.style.left; this.layer.style.top = this.canvas.style.top; this.layer.style.width = this.W + 'px'; this.layer.style.height = this.H + 'px'; }
      this.invalidate();
    }

    setView(v) { Object.assign(this.view, v); this.invalidate(); }
    invalidate() { this.dirty = true; if (!this.opt.manual && !this.raf) this.raf = requestAnimationFrame(() => { this.raf = 0; if (this.dirty) this.draw(); }); }

    project(lat, lng) {
      const v = this.view, m = geo.mercFrac(lat, lng), c = geo.mercFrac(v.lat, v.lng), S = 256 * Math.pow(2, v.zoom);
      let dx = (m.x - c.x); if (dx > 0.5) dx -= 1; else if (dx < -0.5) dx += 1;
      dx *= S; const dy = (m.y - c.y) * S, a = -(v.heading || 0) * D2R, cs = Math.cos(a), sn = Math.sin(a);
      return { x: this.W / 2 + dx * cs - dy * sn, y: this.H / 2 + dx * sn + dy * cs };
    }
    unproject(x, y) {
      const v = this.view, a = (v.heading || 0) * D2R, cs = Math.cos(a), sn = Math.sin(a), px = x - this.W / 2, py = y - this.H / 2;
      const dx = px * cs - py * sn, dy = px * sn + py * cs, S = 256 * Math.pow(2, v.zoom), c = geo.mercFrac(v.lat, v.lng);
      return { lat: geo.fracToLat(u.clamp(c.y + dy / S, 0.0005, 0.9995)), lng: geo.fracToLng(c.x + dx / S) };
    }

    addMarker(el, lat, lng) { this.layer.appendChild(el); const m = { el, lat, lng }; this.markers.push(m); this.invalidate(); return m; }

    draw() {
      this.dirty = false; TL.frame++;
      const v = this.view, W = this.W, H = this.H, ctx = this.ctx, o = this.opt;
      ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
      ctx.fillStyle = o.background; ctx.fillRect(0, 0, W, H);
      const zoom = u.clamp(v.zoom, o.minZoom, o.maxZoom);
      const zi = u.clamp(Math.floor(zoom + 0.35 + o.bias), o.minZoom, o.maxNative);
      const ts = 256 * Math.pow(2, zoom - zi), n = Math.pow(2, zi), mf = geo.mercFrac(v.lat, v.lng);
      const cx = mf.x * n, cy = mf.y * n, r = Math.hypot(W, H) / 2 / ts + 0.6;
      const x0 = Math.floor(cx - r), x1 = Math.floor(cx + r), y0 = Math.max(0, Math.floor(cy - r)), y1 = Math.min(n - 1, Math.floor(cy + r));
      ctx.save(); ctx.translate(W / 2, H / 2); ctx.rotate(-(v.heading || 0) * D2R);
      for (let ty = y0; ty <= y1; ty++) for (let tx = x0; tx <= x1; tx++) {
        this.tile(ctx, zi, ((tx % n) + n) % n, ty, (tx - cx) * ts, (ty - cy) * ts, ts, Math.hypot(tx + 0.5 - cx, ty + 0.5 - cy));
      }
      ctx.restore();
      if (o.prefetchDeeper && zi < o.maxNative) {          // nạp trước cấp sâu hơn quanh tâm → không bị trống khi zoom tới
        for (let dz = 1; dz <= 2 && zi + dz <= o.maxNative; dz++) {
          const nn = Math.pow(2, zi + dz), ccx = mf.x * nn, ccy = mf.y * nn;
          for (let j = -1; j <= 1; j++) for (let i = -1; i <= 1; i++) TL.get(geo.tileUrl(o.tileUrl, zi + dz, ((Math.floor(ccx) + i) % nn + nn) % nn, u.clamp(Math.floor(ccy) + j, 0, nn - 1)), 3 + dz, Math.hypot(i, j));
        }
      }
      this.markers.forEach((m) => { const p = this.project(m.lat, m.lng); m.el.style.transform = 'translate3d(' + p.x.toFixed(1) + 'px,' + p.y.toFixed(1) + 'px,0)'; });
      TL.evict();
      if (o.onView) o.onView(v);
    }

    tile(ctx, z, x, y, sx, sy, ts, d) {
      const e = TL.get(geo.tileUrl(this.opt.tileUrl, z, x, y), 0, d);
      const a = e.ready ? u.clamp((performance.now() - e.t) / 260, 0, 1) : 0;
      if (a < 1) {                                           // nền tạm: cắt từ tile cha đã có
        for (let k = 1; k <= 6 && z - k >= 0; k++) {
          const p = TL.get(geo.tileUrl(this.opt.tileUrl, z - k, x >> k, y >> k), k, d);
          if (p.ready) { const nn = 1 << k, sw = 256 / nn; ctx.drawImage(p.img, (x & (nn - 1)) * sw, (y & (nn - 1)) * sw, sw, sw, sx, sy, ts + 0.6, ts + 0.6); break; }
        }
      }
      if (a > 0) { if (a < 1) ctx.globalAlpha = a; ctx.drawImage(e.img, sx, sy, ts + 0.6, ts + 0.6); ctx.globalAlpha = 1; if (a < 1) this.invalidate(); }
    }

    /* ---------- tương tác ---------- */
    panBy(dx, dy) {
      const v = this.view, S = 256 * Math.pow(2, v.zoom), c = geo.mercFrac(v.lat, v.lng), a = (v.heading || 0) * D2R;
      const rx = dx * Math.cos(a) - dy * Math.sin(a), ry = dx * Math.sin(a) + dy * Math.cos(a);
      v.lat = geo.fracToLat(u.clamp(c.y - ry / S, 0.0005, 0.9995)); v.lng = geo.fracToLng(c.x - rx / S); this.invalidate();
    }
    zoomAt(dz, px, py) {
      const p = this.unproject(px, py); this.view.zoom = u.clamp(this.view.zoom + dz, this.opt.minZoom, this.opt.maxZoom);
      const q = this.project(p.lat, p.lng); this.panBy(px - q.x, py - q.y);
    }
    bind() {
      const cv = this.box, o = this.opt, pts = this.pointers;
      cv.style.touchAction = o.coop ? 'pan-x pan-y' : 'none'; cv.style.cursor = 'grab';
      const rel = (e) => { const r = cv.getBoundingClientRect(), os = o.overscan; return { x: e.clientX - r.left + (os - 1) / 2 * r.width, y: e.clientY - r.top + (os - 1) / 2 * r.height }; };
      let last = null, startPt = null, t0 = 0, moved = 0, pinch = 0;
      cv.addEventListener('pointerdown', (e) => {
        pts.set(e.pointerId, rel(e)); try { cv.setPointerCapture(e.pointerId); } catch (x) { /* ok */ }
        if (pts.size === 1) { last = rel(e); startPt = rel(e); t0 = performance.now(); moved = 0; } else { const [a, b] = Array.from(pts.values()); pinch = Math.hypot(a.x - b.x, a.y - b.y); }
        cv.style.cursor = 'grabbing';
      });
      cv.addEventListener('pointermove', (e) => {
        if (!pts.has(e.pointerId)) return; const p = rel(e), prev = pts.get(e.pointerId); pts.set(e.pointerId, p);
        if (pts.size === 1) { this.panBy(p.x - last.x, p.y - last.y); moved += Math.abs(p.x - last.x) + Math.abs(p.y - last.y); last = p; }
        else if (pts.size === 2) {
          const [a, b] = Array.from(pts.values()), d = Math.hypot(a.x - b.x, a.y - b.y);
          if (pinch) { const mx = (a.x + b.x) / 2, my = (a.y + b.y) / 2; this.zoomAt(Math.log2(d / pinch), mx, my); this.panBy((p.x - prev.x) / 2, (p.y - prev.y) / 2); }
          pinch = d; moved += 10;
        }
      });
      const up = (e) => {
        const wasOne = pts.size === 1; pts.delete(e.pointerId); cv.style.cursor = 'grab';
        if (wasOne && moved < 6 && performance.now() - t0 < 450 && o.onClick) { const p = rel(e); o.onClick(this.unproject(p.x, p.y), p); }
        pinch = 0; if (pts.size === 1) last = Array.from(pts.values())[0];
      };
      cv.addEventListener('pointerup', up); cv.addEventListener('pointercancel', (e) => { pts.delete(e.pointerId); cv.style.cursor = 'grab'; });
      cv.addEventListener('wheel', (e) => {
        if (o.coop && !(e.ctrlKey || e.metaKey)) return;
        e.preventDefault(); const p = rel(e); this.zoomAt(-e.deltaY * (e.ctrlKey ? 0.01 : 0.0018), p.x, p.y);
      }, { passive: false });
      cv.addEventListener('dblclick', (e) => { const p = rel(e); this.zoomAt(1, p.x, p.y); });
    }

    destroy() {
      TL.listeners.delete(this._tileListener); if (this._ro) this._ro.disconnect(); else if (this._rs) w.removeEventListener('resize', this._rs);
      cancelAnimationFrame(this.raf); this.canvas.remove(); this.layer.remove();
    }
  }
  L.SatMap = SatMap;
})(window);
