/* ============================================================================
 * LAKAFÉ — Hệ thống địa điểm: xác định tọa độ KHÔNG phỏng đoán + công cụ xác nhận (?verify=1)
 * Thứ tự: config (đã nhập) → ghi đè của chủ quán (verify) → geocode địa chỉ → khu vực cấp xã.
 * Ghim chỉ hiện khi tọa độ đến từ nguồn đáng tin; khu vực chỉ để bay tới, không ghim.
 * ========================================================================== */
(function (w) {
  'use strict';
  const L = w.LAKAFE, u = L.util, LOC = w.LAKAFE_LOCATION, CFG = w.LAKAFE_CONFIG;
  const fin = (n) => typeof n === 'number' && isFinite(n);
  let resolved = null, pending = null;

  const norm = (t) => String(t || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/đ/gi, 'd').toLowerCase();
  const distKm = (a, b) => { const r = Math.PI / 180, dLa = (b.lat - a.lat) * r, dLo = (b.lng - a.lng) * r, h = Math.sin(dLa / 2) ** 2 + Math.cos(a.lat * r) * Math.cos(b.lat * r) * Math.sin(dLo / 2) ** 2; return 12742 * Math.asin(Math.min(1, Math.sqrt(h))); };
  const ptOf = (p) => { const l = p && p.location; if (!l) return null; const lat = typeof l.lat === 'function' ? l.lat() : l.lat, lng = typeof l.lng === 'function' ? l.lng() : l.lng; return fin(lat) && fin(lng) ? { lat, lng } : null; };

  /* Tìm CHÍNH ô "LAKAFÉ VN" trên Google Maps (Places API mới): ghim do chủ quán đặt chính xác hơn nhiều so với geocode một chuỗi địa chỉ ở vùng nông thôn.
     An toàn: chỉ nhận ô có tên chứa "lakafe" VÀ nằm trong bán kính quanh khu vực Thống Nhất (tránh trùng tên ở nơi khác). Nếu chủ quán đã nhập Place ID thì tin Place ID. */
  async function geocodePlaces() {
    if (!CFG.googleMapsApiKey || !L.google) throw new Error('Không có Google');
    const lib = await u.withTimeout(L.google.library('places'), 6000, 'google places'), Place = lib && lib.Place;
    if (!Place) throw new Error('Places API (New) không có trên phiên bản này');
    const a = CFG.areaFallback, maxKm = CFG.geocode.placesRadiusKm || 35, fields = ['displayName', 'location', 'formattedAddress'], want = LOC.googleListingName || LOC.name;
    let list = [], byId = !!LOC.googlePlaceId;
    if (byId) { const p = new Place({ id: LOC.googlePlaceId }); await u.withTimeout(p.fetchFields({ fields }), 6000, 'place details'); list = [p]; }
    else {
      const r = await u.withTimeout(Place.searchByText({ textQuery: want + ', ' + LOC.addressSearch, fields, language: 'vi', region: 'vn', maxResultCount: 5, locationBias: { center: { lat: a.lat, lng: a.lng }, radius: Math.min(50000, maxKm * 1000) } }), 7000, 'places search');
      list = (r && r.places) || [];
    }
    for (const p of list) {
      const pt = ptOf(p); if (!pt) continue;
      const name = String(p.displayName || ''), near = distKm(pt, a) <= maxKm;
      if (byId && !near) console.info('[LAKAFE] Place ID cách khu vực Thống Nhất ' + Math.round(distKm(pt, a)) + ' km — kiểm tra lại googlePlaceId.');
      if (byId || (near && /lakafe/.test(norm(name)))) return { lat: pt.lat, lng: pt.lng, precision: 'precise', source: 'google-places (' + (name || LOC.googlePlaceId) + ')', label: p.formattedAddress || LOC.address };
    }
    throw new Error('Places: không thấy ô "' + want + '" trong ' + maxKm + ' km quanh khu vực');
  }

  async function geocodeGoogle() {
    if (!CFG.googleMapsApiKey || !L.google) throw new Error('Không có Google');
    const lib = await u.withTimeout(L.google.library('geocoding'), 6000, 'google geocoding');
    const res = await u.withTimeout(new lib.Geocoder().geocode({ address: LOC.addressSearch, region: 'VN' }), 6000, 'geocode');
    const r = res && res.results && res.results[0]; if (!r) throw new Error('Google: không có kết quả');
    const lt = r.geometry.location_type, precise = (lt === 'ROOFTOP' || (lt === 'RANGE_INTERPOLATED' && !r.partial_match));
    return { lat: r.geometry.location.lat(), lng: r.geometry.location.lng(), precision: precise ? 'precise' : 'approximate', source: 'google-geocoding (' + lt + ')', label: r.formatted_address };
  }

  async function geocodeNominatim() {
    const queries = [[LOC.addressSearch, true], ['Ấp Đức Long 3, Thống Nhất, Đồng Nai, Việt Nam', false], ['Thống Nhất, Đồng Nai, Việt Nam', false]];
    for (const [q, mayBePrecise] of queries) {
      try {
        const url = 'https://nominatim.openstreetmap.org/search?format=jsonv2&limit=1&countrycodes=vn&accept-language=vi&addressdetails=1&q=' + encodeURIComponent(q);
        const r = await u.withTimeout(fetch(url, { headers: { Accept: 'application/json' } }), 3500, 'nominatim');
        if (!r.ok) continue; const j = await r.json(); if (!j || !j[0]) continue;
        const o = j[0], at = String(o.addresstype || o.type || ''), hasNo = !!(o.address && o.address.house_number);
        const precise = mayBePrecise && (hasNo || /^(house|building|shop|amenity|office|retail)$/.test(at));
        return { lat: parseFloat(o.lat), lng: parseFloat(o.lon), precision: precise ? 'precise' : 'approximate', source: 'osm-nominatim (' + at + ')', label: o.display_name };
      } catch (e) { /* thử truy vấn kế */ }
    }
    throw new Error('Nominatim: không có kết quả');
  }

  async function geocode() {
    const g = CFG.geocode, cached = L.store.local.get('geocode', null), key = LOC.addressSearch + '|' + (LOC.googlePlaceId || '') + '|' + (CFG.googleMapsApiKey ? 'g' : '');
    if (cached && cached.res && fin(cached.res.lat) && cached.addr === key && u.isoDaysAgo(cached.ts) < (g.cacheDays || 7)) return cached.res;
    let res = null;
    if (g.useGoogle && CFG.googleMapsApiKey) {
      if (g.usePlaces !== false) { try { res = await geocodePlaces(); } catch (e) { console.info('[LAKAFE] Google Places:', e.message); } }
      if (!res) { try { res = await geocodeGoogle(); } catch (e) { console.info('[LAKAFE] geocode Google:', e.message); } }
    }
    if ((!res || res.precision !== 'precise') && g.useNominatim) { try { const r2 = await geocodeNominatim(); if (!res || r2.precision === 'precise') res = r2; } catch (e) { console.info('[LAKAFE] geocode OSM:', e.message); } }
    if (res) L.store.local.set('geocode', { ts: Date.now(), addr: key, res });
    return res;
  }

  function area() {
    const a = CFG.areaFallback;
    return { lat: a.lat, lng: a.lng, state: 'area', pin: false, source: a.source, label: a.name, precision: 'area' };
  }

  L.location = {
    /* Kết quả: { lat, lng, state, pin, source, label } — state ∈ confirmed|provided|override|geocoded|approximate|area */
    resolve(opt) {
      if (resolved) return Promise.resolve(resolved);
      if (pending) return pending;
      pending = (async () => {
        let r = null;
        if (fin(LOC.latitude) && fin(LOC.longitude)) {
          r = { lat: LOC.latitude, lng: LOC.longitude, state: LOC.confirmed ? 'confirmed' : 'provided', pin: true, source: 'config.js', label: LOC.address };
        } else {
          const ov = L.store.local.get('override', null);
          if (ov && fin(ov.lat) && fin(ov.lng)) r = { lat: ov.lat, lng: ov.lng, state: 'override', pin: true, source: 'công cụ xác nhận (trình duyệt này)', label: LOC.address };
          else if (CFG.geocode.enabled && !(opt && opt.noGeocode)) {
            try { const g = await geocode(); if (g) r = { lat: g.lat, lng: g.lng, state: g.precision === 'precise' ? 'geocoded' : 'approximate', pin: g.precision === 'precise', source: g.source, label: g.label }; } catch (e) { /* dùng khu vực */ }
          }
        }
        resolved = r || area();
        if (!resolved.pin && resolved.state !== 'area') { // geocode gần đúng: dùng làm khu vực bay tới, không ghim
          resolved = Object.assign({}, resolved, { pin: false });
        }
        if (resolved.state !== 'confirmed') console.info('[LAKAFE] Vị trí chưa được xác nhận (' + resolved.state + ', ' + resolved.source + '). Mở ?verify=1 để xác nhận.');
        L.bus.emit('location', resolved);
        return resolved;
      })();
      return pending;
    },
    current: () => resolved,
    area,
    reset() { resolved = null; pending = null; }
  };

  /* ====================== CÔNG CỤ XÁC NHẬN TỌA ĐỘ ====================== */
  const CSS = '.vf{position:fixed;inset:0;z-index:99999;background:rgba(10,8,8,.82);display:grid;place-items:center;padding:12px;font:14px/1.45 system-ui,sans-serif;color:#f4ece4}' +
    '.vf-card{width:min(1080px,100%);height:min(720px,100%);background:#17110f;border:1px solid #4a2a2c;border-radius:16px;display:grid;grid-template-columns:1fr 340px;overflow:hidden}' +
    '.vf-map{position:relative;min-height:320px}.vf-map .satmap-canvas{position:absolute;left:0;top:0}.vf-map .satmap-markers{position:absolute;left:0;top:0;pointer-events:none}' +
    '.vf-side{padding:16px;overflow:auto;border-left:1px solid #3a2326;display:flex;flex-direction:column;gap:10px}.vf-side h2{margin:0;font:600 17px Georgia,serif;letter-spacing:.04em}' +
    '.vf-side label{display:grid;gap:4px;font-size:12px;color:#c9b8ad}.vf-side input,.vf-side textarea{width:100%;background:#0f0a09;border:1px solid #4a2f31;color:#fff;border-radius:8px;padding:8px;font:13px ui-monospace,monospace;box-sizing:border-box}' +
    '.vf-side textarea{min-height:88px;resize:vertical}.vf-row{display:grid;grid-template-columns:1fr 1fr;gap:8px}.vf-btns{display:grid;gap:8px}' +
    '.vf-btns button{background:#7b2d35;border:0;color:#fff;border-radius:9px;padding:10px 12px;font:600 13px system-ui;cursor:pointer}.vf-btns button.alt{background:#2a1c1c;border:1px solid #5a3a3d}.vf-btns button:hover{filter:brightness(1.15)}' +
    '.vf-pin{position:absolute;left:-11px;top:-30px;width:22px;height:30px}.vf-pin:before{content:"";position:absolute;left:3px;top:0;width:16px;height:16px;border-radius:50% 50% 50% 0;background:#e0455a;transform:rotate(-45deg);border:2px solid #fff;box-shadow:0 2px 8px #000a}' +
    '.vf-note{font-size:12px;color:#c9b8ad}.vf-state{padding:8px 10px;border-radius:8px;background:#2a1c1c;font-size:12px}.vf-attr{position:absolute;right:6px;bottom:4px;font-size:10px;color:#fff;text-shadow:0 0 3px #000}' +
    '@media(max-width:820px){.vf-card{grid-template-columns:1fr;grid-template-rows:46% 1fr}.vf-side{border-left:0;border-top:1px solid #3a2326}}';

  /* Nhận: link Google Maps dạng DÀI (…/@lat,lng,17z hoặc …!3dLAT!4dLNG), mã nhúng (…!2dLNG!3dLAT), ?q= / ll= lat,lng, hoặc "lat, lng".
     Ưu tiên ghim của ô (!3d!4d) hơn tâm khung nhìn (@). Link rút gọn maps.app.goo.gl KHÔNG chứa toạ độ — phải mở ra trong trình duyệt trước. */
  function parseCoords(t) {
    t = String(t || ''); try { t = decodeURIComponent(t); } catch (e) { /* giữ nguyên */ }
    const N = '(-?\\d{1,3}\\.\\d+)', ok = (la, ln) => { const lat = parseFloat(la), lng = parseFloat(ln); return fin(lat) && fin(lng) && Math.abs(lat) <= 90 && Math.abs(lng) <= 180 ? { lat, lng } : null; };
    let m = t.match(new RegExp('!3d' + N + '!4d' + N)); if (m) return ok(m[1], m[2]);                          // ghim của ô: lat, lng
    m = t.match(new RegExp('!2d' + N + '!3d' + N)); if (m) return ok(m[2], m[1]);                              // mã nhúng: lng, lat (tâm bản đồ lúc chia sẻ)
    m = t.match(new RegExp('[?&](?:ll|q|query|center|destination|daddr)=' + N + ',\\s*' + N)) || t.match(new RegExp('@' + N + ',' + N));
    if (m) return ok(m[1], m[2]);
    m = t.match(/(-?\d{1,2}\.\d{3,})\s*[,;\s]\s*(-?\d{2,3}\.\d{3,})/);
    return m ? ok(m[1], m[2]) : null;
  }

  L.verify = {
    parse: parseCoords,
    async open() {
      if (document.getElementById('vf')) return;
      const st = L.el('style'); st.textContent = CSS; document.head.appendChild(st);
      const cur = await L.location.resolve();
      const root = L.el('div', 'vf'); root.id = 'vf'; root.setAttribute('role', 'dialog'); root.setAttribute('aria-label', 'Xác nhận vị trí LAKAFÉ');
      root.innerHTML = '<div class="vf-card"><div class="vf-map"><div class="vf-attr"></div></div><div class="vf-side">' +
        '<h2>Xác nhận vị trí LAKAFÉ</h2><div class="vf-note">' + LOC.address + '</div><div class="vf-state"></div>' +
        '<label>Dán link Google Maps DẠNG DÀI, mã nhúng, hoặc "vĩ độ, kinh độ"<input class="vf-paste" placeholder="https://www.google.com/maps/place/…/@10.9,107.1,17z  hoặc  10.912345, 107.123456"></label><div class="vf-hint vf-note" aria-live="polite"></div>' +
        '<div class="vf-row"><label>Vĩ độ<input class="vf-lat" inputmode="decimal"></label><label>Kinh độ<input class="vf-lng" inputmode="decimal"></label></div>' +
        '<div class="vf-btns"><button data-a="save">Lưu & xem thử trên trình duyệt này</button><button class="alt" data-a="copy">Sao chép cấu hình cho config.js</button><button class="alt" data-a="geo">Geocode lại địa chỉ</button><button class="alt" data-a="clear">Xóa ghi đè</button><button class="alt" data-a="close">Đóng</button></div>' +
        '<textarea class="vf-code" readonly></textarea><div class="vf-note">Bấm lên bản đồ đúng cửa quán (zoom sát bằng cuộn chuột / chụm 2 ngón). Kiểm tra bằng ảnh vệ tinh rồi dán 3 dòng cấu hình vào <b>config.js</b> và đặt <b>confirmed: true</b>.</div></div></div>';
      document.body.appendChild(root);
      const $ = (s) => root.querySelector(s), mapBox = $('.vf-map');
      $('.vf-attr').textContent = CFG.tiles.attribution;
      const pin = L.el('div', 'vf-pin');
      const map = new L.SatMap(mapBox, { interactive: true, view: { lat: cur.lat, lng: cur.lng, zoom: cur.pin ? 18 : 15 }, onClick: (p) => set(p.lat, p.lng, true) });
      let pt = cur.pin ? { lat: cur.lat, lng: cur.lng } : null; const marker = map.addMarker(pin, cur.lat, cur.lng); pin.style.display = pt ? '' : 'none';
      const state = () => { $('.vf-state').textContent = 'Trạng thái: ' + cur.state + ' • nguồn: ' + cur.source + (pt ? '' : ' • (chưa có ghim — bấm bản đồ)'); };
      function set(lat, lng, center) {
        lat = +(+lat).toFixed(6); lng = +(+lng).toFixed(6); pt = { lat, lng };
        marker.lat = lat; marker.lng = lng; pin.style.display = ''; $('.vf-lat').value = lat; $('.vf-lng').value = lng;
        $('.vf-code').value = 'latitude: ' + lat + ',\nlongitude: ' + lng + ',\nconfirmed: true,'; if (center) map.invalidate(); else map.setView({ lat, lng });
      }
      if (pt) set(pt.lat, pt.lng); state();
      $('.vf-paste').addEventListener('input', (e) => {
        const v = e.target.value, c = parseCoords(v), h = $('.vf-hint');
        if (c) { set(c.lat, c.lng); map.setView({ zoom: 18 }); h.textContent = 'Đã đọc toạ độ từ nội dung vừa dán — hãy kiểm tra ghim trên ảnh vệ tinh trước khi lưu.'; }
        else h.textContent = /maps\.app\.goo\.gl|goo\.gl\/maps/i.test(v) ? 'Link rút gọn (maps.app.goo.gl) không chứa toạ độ. Hãy mở nó trong trình duyệt, đợi bản đồ tải xong rồi sao chép địa chỉ ở thanh địa chỉ (dạng …/@10.9,107.1,17z…) và dán vào đây.' : (v.trim() ? 'Chưa thấy toạ độ trong nội dung này.' : '');
      });
      ['lat', 'lng'].forEach((k) => $('.vf-' + k).addEventListener('change', () => { const a = parseFloat($('.vf-lat').value), b = parseFloat($('.vf-lng').value); if (fin(a) && fin(b)) set(a, b); }));
      root.addEventListener('click', async (e) => {
        const a = e.target.getAttribute && e.target.getAttribute('data-a'); if (!a) return;
        if (a === 'close') { root.remove(); map.destroy(); }
        if (a === 'save' && pt) { L.store.local.set('override', pt); alert('Đã lưu trên trình duyệt này. Tải lại trang để xem hành trình dừng đúng ghim. Nhớ dán vào config.js để áp dụng cho mọi người.'); }
        if (a === 'clear') { L.store.local.del('override'); L.store.local.del('geocode'); alert('Đã xóa ghi đè và bộ nhớ geocode.'); }
        if (a === 'copy') { const t = $('.vf-code').value; try { await navigator.clipboard.writeText(t); } catch (x) { $('.vf-code').select(); document.execCommand('copy'); } e.target.textContent = 'Đã sao chép ✓'; }
        if (a === 'geo') { L.store.local.del('geocode'); L.location.reset(); const r = await L.location.resolve(); Object.assign(cur, r); map.setView({ lat: r.lat, lng: r.lng, zoom: r.pin ? 18 : 15 }); if (r.pin) set(r.lat, r.lng); state(); }
      });
    }
  };
})(window);
