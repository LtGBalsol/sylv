/* ============================================================================
 * LAKAFÉ — DỮ LIỆU MENU
 * Nguồn: bảng menu của quán (ảnh do chủ quán cung cấp). Giá tính bằng nghìn đồng (30 = 30K).
 * - mark: món có DẤU CHẤM ĐỎ trên menu của quán (nhãn hiển thị đổi ở markLabel).
 * - ing : mã nguyên liệu, tra trong LAKAFE_INFO.ingredients (info-data.js).
 * Nguyên liệu suy ra từ TÊN MÓN, không phải công thức riêng của quán.
 * ========================================================================== */
window.LAKAFE_MENU = {
  markLabel: 'Nổi bật',
  markNote: 'Món có dấu chấm đỏ trên menu của quán',
  categories: [
    {
      id: 'matcha', name: 'Matcha', kicker: 'Signature',
      lead: 'Bột trà xanh nghiền mịn — đánh lạnh, pha sữa hoặc thêm tầng hương.',
      priceCols: ['Đài', 'Nhật'],
      priceNote: 'Hai cột giá theo menu của quán: Đài · Nhật (hai lựa chọn bột matcha).',
      items: [
        { id: 'matcha-latte',   name: 'Matcha Latte',      price: [30, 32], mark: true, ing: ['matcha', 'milk'] },
        { id: 'cold-whisk',     name: 'Cold Whisk',        price: [30, 32], mark: true, ing: ['matcha', 'whisk'] },
        { id: 'caramel-matcha', name: 'Caramel Matcha',    price: [32, 35], ing: ['matcha', 'milk', 'caramel'] },
        { id: 'matcha-cheese',  name: 'Matcha Kem Cheese', price: [32, 35], ing: ['matcha', 'cheese'] },
        { id: 'matcha-dau',     name: 'Matcha Latte Dâu',  price: [32, 35], ing: ['matcha', 'milk', 'strawberry'] },
        { id: 'coconut-matcha', name: 'Coconut Matcha',    price: [32, null], mark: true, ing: ['matcha', 'coconut'] }
      ]
    },
    {
      id: 'cacao', name: 'Cacao & Houjicha', kicker: 'Đậm ấm',
      lead: 'Cacao béo đắng và houjicha rang thơm — hai nốt trầm của thực đơn.',
      items: [
        { id: 'cacao-latte',    name: 'Cacao Latte',       price: [25], ing: ['cacao', 'milk'] },
        { id: 'cacao-oreo',     name: 'Cacao Cheese Oreo', price: [32], mark: true, ing: ['cacao', 'cheese', 'oreo'] },
        { id: 'cacao-bachha',   name: 'Cacao Bạc Hà',      price: [27], mark: true, ing: ['cacao', 'mint'] },
        { id: 'houjicha-latte', name: 'Houjicha Latte',    price: [28], ing: ['houjicha', 'milk'] },
        { id: 'houjicha-caramel', name: 'Houjicha Caramel', price: [30], ing: ['houjicha', 'milk', 'caramel'] }
      ]
    },
    {
      id: 'caphe', name: 'Cà phê', kicker: 'Phin & espresso',
      lead: 'Từ ly phin đen thuần tới những biến tấu béo ngọt.',
      items: [
        { id: 'phin-den',    name: 'Phin Đen',       price: [18], ing: ['coffee'] },
        { id: 'phin-sua',    name: 'Phin Sữa',       price: [20], ing: ['coffee', 'condensed'] },
        { id: 'bac-siu',     name: 'Bạc Sỉu',        price: [20], ing: ['coffee', 'condensed', 'milk'] },
        { id: 'ca-phe-muoi', name: 'Cà Phê Muối',    price: [22], ing: ['coffee', 'salt'] },
        { id: 'latte-cafe',  name: 'Latte Café',     price: [22], ing: ['coffee', 'milk'] },
        { id: 'phin-hanh-nhan', name: 'Phin Hạnh Nhân', price: [27], mark: true, ing: ['coffee', 'almond'] }
      ]
    },
    {
      id: 'trasua', name: 'Trà sữa', kicker: 'Béo mịn',
      lead: 'Trà nền ấm, sữa béo và những lớp hương như gạo rang, hạt dẻ, khoai môn.',
      items: [
        { id: 'ts-gao-rang',  name: 'Trà Sữa Gạo Rang',   price: [30], ing: ['tea', 'milk', 'rice'] },
        { id: 'ts-socola',    name: 'Trà Sữa Socola',     price: [30], ing: ['tea', 'milk', 'chocolate'] },
        { id: 'ts-hat-de',    name: 'Trà Sữa Hạt Dẻ',     price: [30], ing: ['tea', 'milk', 'chestnut'] },
        { id: 'ts-nguyen-ban', name: 'Trà Sữa Nguyên Bản', price: [27], ing: ['tea', 'milk'] },
        { id: 'ts-full',      name: 'Trà Sữa Full Topping', price: [32], ing: ['tea', 'milk', 'toppings'] },
        { id: 'ts-hanh-nhan', name: 'Trà Sữa Hạnh Nhân',  price: [30], ing: ['tea', 'milk', 'almond'] },
        { id: 'ts-kem-cheese', name: 'Trà Sữa Kem Cheese', price: [30], ing: ['tea', 'milk', 'cheese'] },
        { id: 'ts-khoai-mon', name: 'Trà Sữa Khoai Môn',  price: [30], mark: true, ing: ['tea', 'milk', 'taro'] }
      ]
    },
    {
      id: 'tratraicay', name: 'Trà trái cây', kicker: 'Thanh mát',
      lead: 'Trà thơm hương lài, lục trà và trái cây theo mùa vị — mát và nhẹ.',
      items: [
        { group: 'Bestseller', id: 'tu-quy-lai',   name: 'Tứ Quý Hương Lài', price: [30], mark: true, ing: ['jasmine', 'oolong'] },
        { group: 'Bestseller', id: 'tra-nho-lai',  name: 'Trà Nho Hương Lài', price: [30], ing: ['jasmine', 'grape'] },
        { group: 'Bestseller', id: 'tra-sen-vang', name: 'Trà Sen Vàng',      price: [30], ing: ['tea', 'lotus'] },
        { group: 'Trà thanh vị', id: 'luc-tra-nhan', name: 'Lục Trà Nhãn',    price: [30], ing: ['greentea', 'longan'] },
        { group: 'Trà thanh vị', id: 'luc-buoi-hong', name: 'Lục Bưởi Hồng',  price: [30], ing: ['greentea', 'pomelo'] },
        { group: 'Trà thanh vị', id: 'phuc-anh-dao', name: 'Phúc Anh Đào',    price: [30], ing: ['tea', 'cherry'] },
        { group: 'Các loại', id: 'tra-dau',     name: 'Trà Dâu',           price: [30], ing: ['tea', 'strawberry'] },
        { group: 'Các loại', id: 'tra-oi-hong', name: 'Trà Ổi Hồng',       price: [30], ing: ['tea', 'guava'] },
        { group: 'Các loại', id: 'tra-dua-luoi', name: 'Trà Dưa Lưới',     price: [30], ing: ['tea', 'melon'] },
        { group: 'Các loại', id: 'tra-tao-xanh', name: 'Trà Táo Xanh',     price: [30], ing: ['tea', 'apple'] },
        { group: 'Các loại', id: 'tra-luu-do',  name: 'Trà Lựu Đỏ',        price: [27], ing: ['tea', 'pomegranate'] },
        { group: 'Các loại', id: 'tra-viet-quat', name: 'Trà Việt Quất',   price: [27], ing: ['tea', 'blueberry'] },
        { group: 'Các loại', id: 'dac-thom-lai', name: 'Đác Thơm Hương Lài', price: [27], ing: ['jasmine', 'palmseed', 'pineapple'] },
        { group: 'Các loại', id: 'tra-dao',     name: 'Trà Đào',           price: [30], ing: ['tea', 'peach'] },
        { group: 'Các loại', id: 'tra-dao-cam-sa', name: 'Trà Đào Cam Sả', price: [30], ing: ['tea', 'peach', 'orange', 'lemongrass'] },
        { group: 'Các loại', id: 'tra-dao-cam-thach', name: 'Trà Đào Cam Thạch', price: [30], ing: ['tea', 'peach', 'orange', 'jelly'] },
        { group: 'Các loại', id: 'tra-vai',     name: 'Trà Vải',           price: [30], ing: ['tea', 'lychee'] },
        { group: 'Các loại', id: 'tra-vai-cam-sa', name: 'Trà Vải Cam Sả', price: [30], ing: ['tea', 'lychee', 'orange', 'lemongrass'] }
      ]
    },
    {
      id: 'yaourt', name: 'Yaourt & Soda', kicker: 'Sảng khoái',
      lead: 'Chua nhẹ, mát lạnh — yaourt mịn và soda có ga.',
      items: [
        { id: 'yaourt-dau',    name: 'Yaourt Dâu',        price: [27], ing: ['yogurt', 'strawberry'] },
        { id: 'yaourt-hat-dac', name: 'Yaourt Hạt Đác',   price: [27], mark: true, ing: ['yogurt', 'palmseed'] },
        { id: 'yaourt-viet-quat', name: 'Yaourt Việt Quất', price: [27], ing: ['yogurt', 'blueberry'] },
        { id: 'soda-blue',     name: 'Soda Blue',         price: [27], ing: ['soda', 'blue'] },
        { id: 'soda-viet-quat', name: 'Soda Việt Quất',   price: [27], ing: ['soda', 'blueberry'] },
        { id: 'soda-bac-ha',   name: 'Soda Bạc Hà / Chanh', price: [27], ing: ['soda', 'mint', 'lemon'] }
      ]
    }
  ]
};
