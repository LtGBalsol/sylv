/* ============================================================================
 * LAKAFÉ — CẤU HÌNH TRUNG TÂM
 * Chỉ cần sửa file này (địa điểm, API key, nhãn hành trình, nguồn ảnh).
 * ========================================================================== */
(function (w) {
  'use strict';

  /* ---------- 1. ĐỊA ĐIỂM ------------------------------------------------
   * KHÔNG tự bịa tọa độ. Quy trình xác nhận:
   *   a) Mở website với  ?verify=1  → kéo/bấm trên bản đồ vệ tinh để đặt ghim đúng cửa quán.
   *   b) Bấm "Sao chép cấu hình", dán latitude / longitude vào đây, đặt confirmed: true.
   * Khi latitude/longitude còn null, website tự geocode địa chỉ (Google nếu có key,
   * không thì OpenStreetMap Nominatim) và chỉ ghim khi độ chính xác ở mức nhà/số nhà.
   * ------------------------------------------------------------------------ */
  w.LAKAFE_LOCATION = {
    name: 'LAKAFÉ',
    address: '209/C3 Ấp Đức Long 3, Thống Nhất, Đồng Nai',
    addressSearch: '209/C3 Ấp Đức Long 3, Thống Nhất, Đồng Nai, Việt Nam',
    phone: '0922 248 509',
    phoneIntl: '+84922248509',
    latitude: null,
    longitude: null,
    confirmed: false,
    groundAltitudeMeters: null, // null = tự hỏi Elevation API (nếu có) rồi mới dùng 0

    /* Ghim Google Maps của quán do chủ quán cung cấp (tên trên Google: "LAKAFÉ VN").
     * Dùng cho nút "Chỉ đường" / "Xem trên Google Maps" — đúng cách Google khuyến nghị. */
    googleMapsUrl: 'https://maps.app.goo.gl/qcW3iamJri6E9THq5',
    googleListingName: 'LAKAFÉ VN',

    /* TUỲ CHỌN — cách nhanh nhất để dùng Google Maps cho đúng vị trí quán:
     *  • googlePlaceId: Place ID của ô "LAKAFÉ VN" (bắt đầu bằng "ChIJ…"). Có key thì website tự lấy đúng ghim của chủ quán.
     *    Để trống cũng được: website sẽ tìm ô theo tên + địa chỉ (xem geocode.usePlaces).
     *  • googleEmbedUrl: dán phần src="…" của mã nhúng (Google Maps → Chia sẻ → Nhúng bản đồ → Sao chép HTML).
     *    Không cần API key. Khi có, mục "Ghé thăm" hiển thị bản đồ Google thật thay cho ảnh vệ tinh Esri. */
    googlePlaceId: '',
    googleEmbedUrl: '',

    /* ⚠ CẦN XÁC NHẬN: bảng menu ghi 08:00–17:00 (T2–T7), 07:00–16:00 (CN),
     * nhưng trang Google Maps (chụp 07/11/2026) ghi "Đóng cửa vào 22:00". */
    hours: [
      { days: 'Thứ Hai – Thứ Bảy', time: '08:00 – 17:00' },
      { days: 'Chủ Nhật', time: '07:00 – 16:00' }
    ]
  };

  /* ---------- 2. CẤU HÌNH CHUNG ------------------------------------------ */
  w.LAKAFE_CONFIG = {
    /* Google Maps Platform — KHÓA PHẢI giới hạn theo HTTP referrer + chỉ bật
     * "Maps JavaScript API" (và Geocoding/Elevation nếu muốn). Xem README. */
    googleMapsApiKey: '',
    googleMapsVersion: 'weekly',
    google3d: {
      enabled: true,
      mode: 'SATELLITE',        // 'SATELLITE' (sạch) hoặc 'HYBRID' (có nhãn)
      prewarmSeconds: 3.5,      // khởi tạo trước handoff để tile kịp tải
      handoffStage: 'vietnam',  // đổi sang Google khi camera tới giai đoạn này
      steadyTimeoutMs: 4500,    // quá hạn mà chưa "steady" thì bỏ Google, dùng ảnh vệ tinh 2D
      finalTilt: 62
    },

    intro: {
      autoplay: 'session',      // 'always' | 'session' (mỗi phiên 1 lần) | 'never'
      speed: 1,                 // >1 chậm hơn, <1 nhanh hơn
      maxLoadSeconds: 9,        // quá hạn tải → chuyển sang phương án thay thế
      finalTilt: 55,
      orbitDegrees: 80
    },

    /* Nhãn các chặng (đúng thứ tự spec). Đổi 'GIA KIỆM' nếu địa phương khác. */
    stages: [
      { id: 'space',   label: 'SPACE',          sub: 'Không gian' },
      { id: 'earth',   label: 'EARTH',          sub: 'Trái Đất' },
      { id: 'asia',    label: 'ASIA',           sub: 'Châu Á' },
      { id: 'sea',     label: 'SOUTHEAST ASIA', sub: 'Đông Nam Á' },
      { id: 'vietnam', label: 'VIETNAM',        sub: 'Việt Nam' },
      { id: 'dongnai', label: 'ĐỒNG NAI',       sub: 'Tỉnh Đồng Nai' },
      { id: 'giakiem', label: 'GIA KIỆM',       sub: 'Khu vực Gia Kiệm' },
      { id: 'lakafe',  label: 'LAKAFÉ',         sub: 'Điểm đến' }
    ],

    /* Chỉ để dựng KHUNG camera ở cấp châu lục / quốc gia — không phải vị trí quán. */
    frames: {
      asia:    { lat: 24.0, lng: 102.0 },
      sea:     { lat: 13.5, lng: 106.0 },
      vietnam: { lat: 14.5, lng: 107.6 }
    },

    /* Khu vực dự phòng (cấp xã) khi chưa có tọa độ quán: Wikipedia "Thống Nhất, Đồng Nai"
     * ghi 11°04′33″N 107°09′04″E. Chỉ dùng để bay tới KHU VỰC, không ghim quán. */
    areaFallback: {
      name: 'Thống Nhất, Đồng Nai',
      lat: 11.07583, lng: 107.15111,
      source: 'Wikipedia — Thống Nhất, Đồng Nai (xã, thành lập 16/6/2025)'
    },

    /* usePlaces: tìm CHÍNH ô "LAKAFÉ VN" bằng Places API (New) — chính xác hơn geocode địa chỉ nông thôn; chỉ nhận kết quả nếu tên khớp "lakafe"
     * và nằm trong placesRadiusKm quanh khu vực Thống Nhất. Mỗi lượt tính phí (xem README) → chỉ cần chạy 1 lần để lấy toạ độ, rồi dán vào
     * latitude/longitude ở trên và đặt geocode.enabled:false khi chạy thật. */
    geocode: { enabled: true, useGoogle: true, usePlaces: true, placesRadiusKm: 35, useNominatim: true, cacheDays: 7 },

    /* Texture Trái Đất. Thử lần lượt từng URL; thành công URL nào thì ghi nguồn đúng URL đó. */
    textures: {
      day: [
        { url: 'assets/tex/earth_day_4k.jpg', credit: 'NASA Blue Marble (tệp cục bộ)', optional: true },
        { url: 'https://gibs.earthdata.nasa.gov/wms/epsg4326/best/wms.cgi?SERVICE=WMS&VERSION=1.1.1&REQUEST=GetMap&LAYERS=BlueMarble_NextGeneration&STYLES=&SRS=EPSG:4326&BBOX=-180,-90,180,90&WIDTH={w}&HEIGHT={h}&FORMAT=image/jpeg', credit: 'NASA Blue Marble Next Generation — NASA Earth Observatory / GIBS' },
        { url: 'https://gibs.earthdata.nasa.gov/wms/epsg4326/best/wms.cgi?SERVICE=WMS&VERSION=1.1.1&REQUEST=GetMap&LAYERS=BlueMarble_ShadedRelief_Bathymetry&STYLES=&SRS=EPSG:4326&BBOX=-180,-90,180,90&WIDTH={w}&HEIGHT={h}&FORMAT=image/jpeg', credit: 'NASA Blue Marble Shaded Relief & Bathymetry — NASA GIBS' },
        { url: 'https://eoimages.gsfc.nasa.gov/images/imagerecords/57000/57752/land_shallow_topo_2048.jpg', credit: 'NASA Visible Earth — Blue Marble (Reto Stöckli, NASA Earth Observatory)' },
        { url: 'https://services.arcgisonline.com/arcgis/rest/services/World_Imagery/MapServer/export?bbox=-180,-90,180,90&bboxSR=4326&imageSR=4326&size={w},{h}&format=jpg&f=image', credit: 'Esri World Imagery (texture dự phòng)' }
      ],
      night: [
        { url: 'https://gibs.earthdata.nasa.gov/wms/epsg4326/best/wms.cgi?SERVICE=WMS&VERSION=1.1.1&REQUEST=GetMap&LAYERS=VIIRS_Black_Marble&STYLES=&SRS=EPSG:4326&BBOX=-180,-90,180,90&WIDTH={w}&HEIGHT={h}&FORMAT=image/jpeg', credit: 'NASA Black Marble — NASA Earth Observatory / GIBS' }
      ],
      clouds: [
        { url: 'https://eoimages.gsfc.nasa.gov/images/imagerecords/57000/57747/cloud_combined_2048.jpg', credit: 'NASA Visible Earth — Blue Marble clouds' }
      ]
    },

    /* Ảnh vệ tinh theo cấp zoom (fallback 2D + lớp chi tiết trên địa cầu). */
    tiles: {
      url: 'https://services.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
      minZoom: 5,
      maxZoom: 17,
      attribution: 'Imagery © Esri, Maxar, Earthstar Geographics, and the GIS User Community'
    },

    /* Thư viện ngoài duy nhất: three.js (tải động, có dự phòng). Không dùng GSAP — animation chạy bằng CSS + một vòng rAF. */
    cdn: {
      three: [
        'https://cdn.jsdelivr.net/npm/three@0.170.0/build/three.module.min.js',
        'https://unpkg.com/three@0.170.0/build/three.module.min.js'
      ]
    }
  };
})(window);
